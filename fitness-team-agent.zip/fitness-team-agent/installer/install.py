# -*- coding: utf-8 -*-
"""安装器状态机（确定性优先：凡是不允许模型选择的事，用代码让它做不了）。

场景：feishu_channel —— 打通飞书通道（办公助理主线，唯一路线）。
状态机硬编码六状态唯一路线，任何 AI 模型只能逐步调用本脚本推进，
失败即停、输出结构化信封，不提供任何备选路线。

状态定义：
  S1_BRIDGE_CHECK      断言：办公助理已启用并绑定飞书（桥接凭证文件可读、appId/appSecret 非空）
  S2_INJECT_CREDENTIALS 动作：凭证注入 lark-cli。两种凭证模式自动适应：
                       ① 传统宿主发行版：config init --app-secret-stdin --force-init；
                       ② 宿主托管凭证（config 报 "credentials are provided externally"）：
                          环境变量覆写（APP_ID/APP_SECRET/TENANT_ACCESS_TOKEN/STRICT_MODE=off，
                          并移除宿主注入的 user token），用 whoami 验证 bot 身份可用后放行
  S3_LOCATE_P2P        动作：定位与用户的单聊会话，写入 channel.json（保留现有 base 段）。
                       确定性定位：直接向用户 open_id 发定位消息、从响应取回 chat_id，
                       不依赖会话预先存在、不需要用户手动发消息
  S4_TEST_SEND         动作：bot 身份发送测试消息（直调飞书 API，不走推送例程，避免出口围栏冲突）
  S5_DEPLOY_BASE       动作：部署基地（调度技能占位符替换 + 全局技能同步 + skill-config 合并注册 + 记忆指针）
  S6_ACCEPTANCE        人工门：飞书端验收，用户确认后由 complete 命令收尾

用法：
  python install.py status    --project-root <项目根>
  python install.py next      --project-root <项目根> [--pick <chat_id>]
  python install.py complete  --project-root <项目根> --state S6_ACCEPTANCE --confirmed
  python install.py reset     --project-root <项目根> --yes                     # 清空状态重头再来

只有以上四个命令：finish（兜底路线手动标记 DONE）随自建应用兜底路线一并废除，
2026-09-05 移除——状态机不存在任何人工标记完成的旁路，DONE 只能由 S6 验收产生。

信封格式（stdout 单行 JSON）：
  {"ok":true/false, "scenario":"feishu_channel", "status":..., "state":...,
   "message":"...", "user_action":"...（需要用户出手时才有）", ...}
失败时退出码 1，成功时退出码 0。
"""
import argparse
import glob
import json
import os
import shutil
import subprocess
import sys
import urllib.request
from datetime import datetime

SCHEMA_VERSION = 1
SCENARIO = "feishu_channel"

ORDER = [
    "S1_BRIDGE_CHECK",
    "S2_INJECT_CREDENTIALS",
    "S3_LOCATE_P2P",
    "S4_TEST_SEND",
    "S5_DEPLOY_BASE",
    "S6_ACCEPTANCE",
]

STATE_DESC = {
    "S1_BRIDGE_CHECK": "断言办公助理已启用并绑定飞书（桥接凭证可读）",
    "S2_INJECT_CREDENTIALS": "凭证注入 lark-cli",
    "S3_LOCATE_P2P": "定位与用户的单聊会话并写入 channel.json",
    "S4_TEST_SEND": "bot 身份发送测试消息",
    "S5_DEPLOY_BASE": "部署基地（全局技能同步 + 记忆指针）",
    "S6_ACCEPTANCE": "飞书端人工验收",
}

MEMORY_SECTION_HEADER = "## Fitness Team Role"


def build_memory_section(project_root):
    """记忆指针段：路径由 --project-root 现算（安装器必须机器无关，不硬编码路径）。"""
    root = os.path.abspath(project_root)
    return f"""{MEMORY_SECTION_HEADER}

触发词：健身、训练、三餐、打卡、体测、体重、配餐、训练计划、鼓励、晚间汇报、周期复盘、大总管、早餐、午餐、晚餐、训练完成。
强制指令：命中任一触发词时，处理前必须先调用 fitness-team-dispatch 技能（全局技能），由它加载团队铁律与数据区路径后再行事。
团队铁律：{root}\\.trae\\rules\\team-iron-rules.md
数据区（一切读写必须用此绝对路径；铁律中的相对路径如 fitness-team/... 一律映射到此路径，禁止按会话工作区解析相对路径）：{root}\\fitness-team\\
通道围栏：飞书推送一律走 feishu-push 技能；通道状态机未 DONE 时推送例程自动拒发；打通通道只走 channel-setup 技能。
"""

FALLBACK_BIND_ACTION = (
    "请在 TraeWork 客户端启用『办公助理』并绑定你的飞书账号，完成后重跑本步。"
    "这是唯一路线，团队不提供任何备选路线。"
)


# ---------------------------------------------------------------- 基础工具

def envelope(ok, message, **extra):
    """统一信封：成功/失败都从这里出去。"""
    e = {"ok": ok, "scenario": SCENARIO, "message": message}
    e.update(extra)
    return e


def emit(env_dict, exit_code=None):
    print(json.dumps(env_dict, ensure_ascii=False))
    if exit_code is None:
        exit_code = 0 if env_dict.get("ok") else 1
    sys.exit(exit_code)


def mask(text, secret):
    """输出前掩码：任何位置出现的密钥一律替换为 ***（铁律 9.4）。"""
    if text and secret:
        return text.replace(secret, "***")
    return text


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def state_path(project_root):
    return os.path.join(project_root, "fitness-team", "install-state.json")


def load_state(project_root):
    p = state_path(project_root)
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return fresh_state()


def fresh_state():
    return {
        "schema_version": SCHEMA_VERSION,
        "scenarios": {
            SCENARIO: {"status": "NOT_STARTED", "current_state": None, "history": []}
        },
    }


def save_state(project_root, st):
    p = state_path(project_root)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=2)


def scen(st):
    return st.setdefault("scenarios", {}).setdefault(
        SCENARIO, {"status": "NOT_STARTED", "current_state": None, "history": []}
    )


def record(sc, event, state, detail=""):
    sc.setdefault("history", []).append(
        {"time": now_iso(), "event": event, "state": state, "detail": detail}
    )


# ---------------------------------------------------------------- 与 push.py 同逻辑的辅助函数
# 安装器自包含，不 import 技能目录代码（S2 发生在任何技能可用之前）。

def find_cli():
    """定位 lark-cli：先走 PATH（宿主注入），失败再扫描飞书插件安装目录兜底。"""
    exe = shutil.which("lark-cli")
    if exe:
        return exe
    home = os.path.expanduser("~")
    patterns = [
        os.path.join(home, ".trae-cn", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
        os.path.join(home, ".trae", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
    ]
    candidates = []
    for pat in patterns:
        candidates.extend(glob.glob(pat))
    if candidates:
        return sorted(candidates)[-1]
    return None


def find_bridge_workspace():
    """定位办公助理桥接凭证文件的 feishu workspace 段（只读，铁律 9.4）。绝不回显内容。"""
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    patterns = [
        os.path.join(appdata, "TRAE*", "User", "globalStorage",
                     "cloudide.icube-im-bridge", "feishu-bridge", "*", "channel_config.json"),
    ]
    candidates = []
    for pat in patterns:
        candidates.extend(glob.glob(pat))
    for p in sorted(candidates):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            continue
        ws = ((data.get("channels") or {}).get("feishu") or {}).get("workspace") or {}
        if ws.get("appSecret"):
            return ws
    return None


def fetch_tenant_token(app_id, secret, brand="feishu"):
    """用 App ID + Secret 现换 tenant_access_token（短期有效，不落盘）。"""
    host = "https://open.larksuite.com" if brand == "lark" else "https://open.feishu.cn"
    body = json.dumps({"app_id": app_id, "app_secret": secret}).encode("utf-8")
    req = urllib.request.Request(
        host + "/open-apis/auth/v3/tenant_access_token/internal",
        data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if data.get("code") != 0:
        raise RuntimeError(f"token 换取失败: code={data.get('code')} msg={data.get('msg')}")
    return data["tenant_access_token"]


def read_channel(project_root):
    p = os.path.join(project_root, "fitness-team", "channel.json")
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f), p
    except (OSError, json.JSONDecodeError):
        return {}, p


def write_channel(project_root, updates):
    """合并写 channel.json：只更新指定键，保留现有 base 段等其余内容。"""
    channel, p = read_channel(project_root)
    channel.update(updates)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(channel, f, ensure_ascii=False, indent=2)
    return channel


# ---------------------------------------------------------------- 各状态执行器
# 约定：动作成功返回 None，或返回不含 message 键的 detail dict（由引擎自动推进）；
# 返回含 wait=True 的 dict 表示人工门；返回含 message 键的 dict 表示失败
# （含 user_action 时需要用户出手）。

def s1_bridge_check(project_root, args):
    ws = find_bridge_workspace()
    if not ws or not ws.get("appId") or not ws.get("appSecret"):
        return {
            "message": "S1 断言失败：未找到办公助理桥接凭证（或 appId/appSecret 为空），办公助理未启用或飞书未绑定。",
            "user_action": FALLBACK_BIND_ACTION,
        }
    return None


def _verify_env_mode(exe, ws):
    """环境变量注入模式验证：覆写宿主注入的凭证环境变量，确认桥接应用的 bot 身份可用。

    宿主托管凭证的发行版会把 LARKSUITE_CLI_APP_ID / LARKSUITE_CLI_BRAND /
    LARKSUITE_CLI_USER_ACCESS_TOKEN 注入终端环境，并把 strict mode 锁为 user。
    此处覆写为桥接应用凭证（含现换的 tenant token）并移除 user token，
    用 whoami --as bot 验证。全程不回显任何凭证内容（铁律 9.4）。
    """
    secret = ws["appSecret"]
    env = dict(os.environ)
    env["LARKSUITE_CLI_APP_ID"] = ws["appId"]
    env["LARKSUITE_CLI_APP_SECRET"] = secret
    env["LARKSUITE_CLI_STRICT_MODE"] = "off"
    env["LARKSUITE_CLI_BRAND"] = "feishu"
    env.pop("LARKSUITE_CLI_USER_ACCESS_TOKEN", None)
    try:
        env["LARKSUITE_CLI_TENANT_ACCESS_TOKEN"] = fetch_tenant_token(ws["appId"], secret)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "reason": f"tenant token 换取失败: {e}"}
    argv = [exe, "whoami", "--as", "bot"]
    if exe.lower().endswith((".cmd", ".bat")):
        argv = ["cmd", "/c"] + argv
    try:
        r = subprocess.run(argv, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", env=env, timeout=60)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "reason": f"whoami 调用异常: {e}"}
    raw = r.stdout.strip() or r.stderr.strip()
    try:
        info = json.loads(raw)
    except json.JSONDecodeError:
        return {"ok": False, "reason": f"whoami 输出无法解析（退出码 {r.returncode}）",
                "stdout": mask(r.stdout, secret)[:500], "stderr": mask(r.stderr, secret)[:500]}
    if (r.returncode == 0 and info.get("available") and info.get("tokenStatus") == "ready"
            and info.get("identity") == "bot" and info.get("appId") == ws["appId"]):
        return {"ok": True}
    return {"ok": False, "reason": "whoami 验证未通过",
            "identity": info.get("identity"), "available": info.get("available"),
            "tokenStatus": info.get("tokenStatus"),
            "appIdMatchesBridge": info.get("appId") == ws["appId"],
            "error": info.get("error")}


def s2_inject_credentials(project_root, args):
    ws = find_bridge_workspace()
    if not ws or not ws.get("appId") or not ws.get("appSecret"):
        return {"message": "S2 失败：桥接凭证不可读，请先完成 S1。", "user_action": FALLBACK_BIND_ACTION}
    exe = find_cli()
    if not exe:
        return {"message": "S2 失败：找不到 lark-cli（PATH 与飞书插件目录均无）。请确认 TraeWork 飞书插件已安装。"}
    app_id, secret = ws["appId"], ws["appSecret"]

    # 模式①：传统宿主发行版，config init 持久化凭证
    argv = [exe, "config", "init", "--app-id", app_id, "--app-secret-stdin", "--brand", "feishu", "--force-init"]
    if exe.lower().endswith((".cmd", ".bat")):
        argv = ["cmd", "/c"] + argv
    env = dict(os.environ)
    env["LARKSUITE_CLI_STRICT_MODE"] = "off"
    try:
        r = subprocess.run(
            argv, input=secret, capture_output=True, text=True,
            encoding="utf-8", errors="replace", env=env, timeout=60,
        )
    except Exception as e:  # noqa: BLE001
        return {"message": f"S2 失败：lark-cli 调用异常: {e}"}
    stdout, stderr = mask(r.stdout, secret), mask(r.stderr, secret)
    if r.returncode == 0:
        return {"detail": {"credential_mode": "config_init"}}

    # 模式②：宿主托管凭证（config 交互式管理不支持），改走环境变量注入验证
    if "credentials are provided externally" not in (r.stderr or ""):
        return {"message": f"S2 失败：lark-cli config init 退出码 {r.returncode}", "stderr": stderr, "stdout": stdout}
    verify = _verify_env_mode(exe, ws)
    if verify.get("ok"):
        return {"detail": {
            "credential_mode": "env",
            "note": "宿主托管凭证（config 不支持）：已验证环境变量注入模式下桥接应用 bot 身份可用。",
        }}
    return {"message": "S2 失败：宿主不支持 config init，环境变量注入模式验证也未通过",
            "stderr": stderr, "detail": verify}


def _list_chats(token):
    """列出机器人所在会话（翻页取全量）。出错抛 RuntimeError，由调用方收信封。"""
    chats = []
    page_token = ""
    base = "https://open.feishu.cn/open-apis/im/v1/chats"
    while True:
        url = base + "?page_size=100"
        if page_token:
            url += "&page_token=" + page_token
        req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token})
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if data.get("code") != 0:
            raise RuntimeError(f"列会话错误 code={data.get('code')} msg={data.get('msg')}")
        items = (data.get("data") or {}).get("items") or []
        chats.extend(items)
        d = data.get("data") or {}
        if d.get("has_more") and d.get("page_token"):
            page_token = d["page_token"]
        else:
            break
    return chats


def _locate_by_open_id(token, open_id):
    """确定性定位：向用户 open_id 发定位消息，从发送响应取回 p2p 会话 chat_id。

    飞书在首条消息时自动创建 p2p 会话，因此本路线不依赖会话预先存在、
    不需要用户手动给机器人发消息（旧流程「连接成功后机器人自发测试消息」的语义）。
    """
    body = json.dumps({
        "receive_id": open_id,
        "msg_type": "text",
        "content": json.dumps({"text": "健身团队安装程序：正在定位本会话，稍后会发送正式测试消息（自动消息，无需回复）。"}),
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id",
        data=body,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": "Bearer " + token,
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if data.get("code") != 0:
        raise RuntimeError(f"定位消息发送失败 code={data.get('code')} msg={data.get('msg')}")
    chat_id = (data.get("data") or {}).get("chat_id")
    if not chat_id:
        raise RuntimeError("定位消息已发出，但响应中没有 chat_id，无法写入通道配置。")
    return chat_id


def s3_locate_p2p(project_root, args):
    ws = find_bridge_workspace()
    if not ws or not ws.get("appId") or not ws.get("appSecret"):
        return {"message": "S3 失败：桥接凭证不可读，请先完成 S1/S2。", "user_action": FALLBACK_BIND_ACTION}
    app_id, secret = ws["appId"], ws["appSecret"]
    try:
        token = fetch_tenant_token(app_id, secret)
    except Exception as e:  # noqa: BLE001
        return {"message": f"S3 失败：{e}"}

    picked_chat_id = None

    if args.pick:
        # 人工指定路径（降级保留）：仍需在机器人单聊列表中验证存在
        try:
            chats = _list_chats(token)
        except Exception as e:  # noqa: BLE001
            return {"message": f"S3 失败：{e}"}
        p2p = [c for c in chats if c.get("chat_mode") == "p2p"]
        if args.pick not in [c.get("chat_id") for c in p2p]:
            return {"message": f"S3 失败：--pick 指定的会话 {args.pick} 不在机器人单聊列表中，拒绝写入。"}
        picked_chat_id = args.pick
    elif ws.get("userOpenId"):
        # 主路线（确定性）：直接向用户 open_id 发定位消息取回 chat_id。
        # 不依赖会话预先存在、不需要用户手动发消息——与旧流程「连接成功后机器人自发消息」一致。
        try:
            picked_chat_id = _locate_by_open_id(token, ws["userOpenId"])
        except Exception as e:  # noqa: BLE001
            return {"message": f"S3 失败：{e}"}
    else:
        # 降级：桥接凭证缺 userOpenId 时，退回会话列表定位（保留原有指引）
        try:
            chats = _list_chats(token)
        except Exception as e:  # noqa: BLE001
            return {"message": f"S3 失败：{e}"}
        p2p = [c for c in chats if c.get("chat_mode") == "p2p"]
        if len(p2p) == 1:
            picked_chat_id = p2p[0].get("chat_id")
        elif len(p2p) == 0:
            return {
                "message": "S3 失败：机器人所在单聊会话数为 0，且桥接凭证缺少 userOpenId，无法确定性定位目标会话。",
                "user_action": "请在飞书里找到团队机器人，直接给它发一条消息（单聊无需 @），然后重跑本步。",
            }
        else:
            names = "; ".join(
                f"{c.get('chat_id')}（{c.get('name') or '未命名'}）" for c in p2p
            )
            return {
                "message": f"S3 失败：存在 {len(p2p)} 个单聊会话，无法唯一确定目标：{names}",
                "user_action": "请确认哪个是目标会话，然后用 next --pick <chat_id> 指定后重跑本步。",
            }

    channel = write_channel(project_root, {
        "app_id": app_id,
        "target_chat_id": picked_chat_id,
    })
    if not channel.get("base"):
        # 保留语义：仅在原本没有 base 段时补一个空段，避免后续 base_sync 读不到
        write_channel(project_root, {"base": {}})
    return None


def s4_test_send(project_root, args):
    """直调飞书 API 发测试消息（安装器线路验证，不走 push.py，避免出口围栏冲突）。"""
    channel, _ = read_channel(project_root)
    chat_id = channel.get("target_chat_id")
    if not chat_id:
        return {"message": "S4 失败：channel.json 缺少 target_chat_id，请先完成 S3。"}
    ws = find_bridge_workspace()
    if not ws or not ws.get("appId") or not ws.get("appSecret"):
        return {"message": "S4 失败：桥接凭证不可读。", "user_action": FALLBACK_BIND_ACTION}
    try:
        token = fetch_tenant_token(ws["appId"], ws["appSecret"])
    except Exception as e:  # noqa: BLE001
        return {"message": f"S4 失败：{e}"}

    body = json.dumps({
        "receive_id": chat_id,
        "msg_type": "text",
        "content": json.dumps({"text": "飞书通道测试消息：发送链路已打通。你的私人定制健身团队即将上线。"}),
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id",
        data=body,
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": "Bearer " + token,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as e:  # noqa: BLE001
        return {"message": f"S4 失败：发送异常: {e}"}
    if data.get("code") != 0:
        return {"message": f"S4 失败：飞书返回 code={data.get('code')} msg={data.get('msg')}"}
    return None


def s5_deploy_base(project_root, args):
    project_root = os.path.abspath(project_root)
    home = os.path.expanduser("~")
    global_skills_dir = os.path.join(home, ".trae-cn", "skills")
    project_skills_dir = os.path.join(project_root, ".trae", "skills")
    if not os.path.isdir(project_skills_dir):
        return {"message": f"S5 失败：项目技能目录不存在: {project_skills_dir}"}

    synced, registered = [], []

    # 1. 调度技能：替换 <PROJECT_ROOT> 占位符后单独写入（必须先于通用同步，且通用同步跳过它）
    dispatch_src = os.path.join(project_skills_dir, "fitness-team-dispatch", "SKILL.md")
    try:
        with open(dispatch_src, encoding="utf-8") as f:
            dispatch_text = f.read()
    except OSError as e:
        return {"message": f"S5 失败：读取调度技能源文件失败: {e}"}
    if "<PROJECT_ROOT>" not in dispatch_text:
        return {"message": "S5 失败：调度技能源文件缺少 <PROJECT_ROOT> 占位符，分发包可能已损坏。"}
    dispatch_text = dispatch_text.replace("<PROJECT_ROOT>", project_root)
    if "<PROJECT_ROOT>" in dispatch_text:
        return {"message": "S5 失败：占位符替换后仍有残留，中止部署。"}
    dispatch_dst_dir = os.path.join(global_skills_dir, "fitness-team-dispatch")
    os.makedirs(dispatch_dst_dir, exist_ok=True)
    with open(os.path.join(dispatch_dst_dir, "SKILL.md"), "w", encoding="utf-8") as f:
        f.write(dispatch_text)
    synced.append("fitness-team-dispatch")

    # 2. 通用技能同步（跳过 dispatch 防占位符版覆盖替换版，排除 __pycache__）
    for name in sorted(os.listdir(project_skills_dir)):
        if name == "fitness-team-dispatch" or name == "__pycache__":
            continue
        src = os.path.join(project_skills_dir, name)
        if not os.path.isdir(src):
            continue
        shutil.copytree(src, os.path.join(global_skills_dir, name),
                        dirs_exist_ok=True, ignore=shutil.ignore_patterns("__pycache__"))
        synced.append(name)

    # 3. skill-config.json 合并注册（setdefault：已存在条目不覆写）
    cfg_path = os.path.join(home, ".trae-cn", "skill-config.json")
    cfg = {}
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, encoding="utf-8") as f:
                cfg = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            return {"message": f"S5 失败：读取 skill-config.json 失败: {e}"}
    managed = cfg.setdefault("managedSkills", {})
    for name in synced:
        if name not in managed:
            managed[name] = "user_upload"
            registered.append(name)
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

    # 4. 记忆指针：幂等追加（已存在则跳过，不重复写）
    mem_dir = os.path.join(home, ".trae-cn", "memory")
    mem_path = os.path.join(mem_dir, "user_profile.md")
    existing = ""
    if os.path.exists(mem_path):
        with open(mem_path, encoding="utf-8") as f:
            existing = f.read()
    memory_status = "already-present"
    if MEMORY_SECTION_HEADER not in existing:
        os.makedirs(mem_dir, exist_ok=True)
        with open(mem_path, "a", encoding="utf-8") as f:
            if existing and not existing.endswith("\n"):
                f.write("\n")
            f.write("\n" + build_memory_section(project_root))
        memory_status = "appended"

    return {"detail": {"synced": synced, "registered": registered, "memory": memory_status}}


def s6_acceptance(project_root, args):
    """人工门：next 只返回等待指引，完成须由 complete 命令确认。"""
    return {
        "wait": True,
        "message": "S6 等待用户验收：部署已完成，现在进行飞书端验收。",
        "user_action": (
            "请在飞书单聊会话里给团队机器人发一条健身相关消息（例如『体测』，无需 @），"
            "确认办公助理自主调用 fitness-team-dispatch 技能、团队能按铁律应答（可对暗号『铁军』验证人格加载）。"
            "验收通过后，回来执行：complete --state S6_ACCEPTANCE --confirmed"
        ),
    }


EXECUTORS = {
    "S1_BRIDGE_CHECK": s1_bridge_check,
    "S2_INJECT_CREDENTIALS": s2_inject_credentials,
    "S3_LOCATE_P2P": s3_locate_p2p,
    "S4_TEST_SEND": s4_test_send,
    "S5_DEPLOY_BASE": s5_deploy_base,
    "S6_ACCEPTANCE": s6_acceptance,
}


# ---------------------------------------------------------------- 命令实现

def snapshot(sc):
    """status / 各命令共用的进度快照。"""
    status = sc.get("status", "NOT_STARTED")
    cur = sc.get("current_state")
    if status == "DONE":
        next_state, hint = None, "通道已打通，无需再跑安装器。"
    elif cur and cur in ORDER and status == "IN_PROGRESS":
        next_state, hint = cur, STATE_DESC[cur]
    else:
        nxt = ORDER[0] if not cur else ORDER[ORDER.index(cur) + 1] if ORDER.index(cur) + 1 < len(ORDER) else None
        next_state = nxt
        hint = STATE_DESC.get(nxt, "") if nxt else "已是最后一步。"
    return {
        "status": status,
        "current_state": cur,
        "next_state": next_state,
        "next_action_hint": hint,
        "history_len": len(sc.get("history", [])),
    }


def cmd_status(st, args):
    sc = scen(st)
    emit(envelope(True, "当前进度快照。", **snapshot(sc)))


def cmd_next(st, args):
    sc = scen(st)
    if sc.get("status") == "DONE":
        emit(envelope(True, "场景已完成（DONE），无需推进。", **snapshot(sc)))

    cur = sc.get("current_state")
    if not cur or cur not in ORDER:
        state = ORDER[0]
    elif sc.get("status") == "IN_PROGRESS":
        state = cur  # 未完成则重跑当前态
    else:
        idx = ORDER.index(cur)
        if idx + 1 >= len(ORDER):
            emit(envelope(False, "状态异常：已到最后一个状态但状态不是 IN_PROGRESS，请用 status 查看。", **snapshot(sc)))
        state = ORDER[idx + 1]

    sc["status"] = "IN_PROGRESS"
    sc["current_state"] = state
    record(sc, "enter", state)

    result = EXECUTORS[state](args.project_root, args)

    is_success = (result is None
                  or (isinstance(result, dict) and not result.get("wait") and "message" not in result))
    if is_success:
        # 动作成功，自动推进（detail dict 随信封带出，供模型转述）
        record(sc, "pass", state)
        idx = ORDER.index(state)
        extra = {}
        if isinstance(result, dict) and result.get("detail"):
            extra["detail"] = result["detail"]
            # 执行器经 detail 回传的持久化字段（引擎随后以内存态落盘，执行器自写会丢）
            if isinstance(result["detail"], dict) and result["detail"].get("credential_mode"):
                sc["credential_mode"] = result["detail"]["credential_mode"]
        if idx + 1 < len(ORDER):
            sc["current_state"] = ORDER[idx + 1]
            sc["status"] = "IN_PROGRESS"
            save_state(args.project_root, st)
            # 注意：不可再显式传 next_state/next_action_hint，snapshot 已含（重名会 TypeError）
            emit(envelope(True, f"{state} 通过。", **extra, **snapshot(sc)))
        else:
            sc["status"] = "DONE"
            save_state(args.project_root, st)
            emit(envelope(True, f"{state} 通过，场景完成（DONE）。", **extra, **snapshot(sc)))

    if result.get("wait"):
        record(sc, "waiting_user", state)
        save_state(args.project_root, st)
        emit(envelope(True, result.get("message", ""), user_action=result.get("user_action", ""), **snapshot(sc)))

    # 失败：状态保留在当前态，失败即停
    record(sc, "fail", state, result.get("message", ""))
    save_state(args.project_root, st)
    env = envelope(False, result.get("message", ""), state=state, **snapshot(sc))
    if result.get("user_action"):
        env["user_action"] = result["user_action"]
    for k in ("stderr", "stdout", "detail"):
        if result.get(k):
            env[k] = result[k]
    emit(env)


def cmd_complete(st, args):
    sc = scen(st)
    if sc.get("status") == "DONE":
        emit(envelope(True, "场景已完成（DONE）。", **snapshot(sc)))
    if args.state != "S6_ACCEPTANCE" or sc.get("current_state") != "S6_ACCEPTANCE":
        emit(envelope(
            False,
            f"complete 仅接受当前态 S6_ACCEPTANCE；当前态为 {sc.get('current_state')}。禁止跳态。",
            **snapshot(sc)))
    if not args.confirmed:
        emit(envelope(False, "缺少 --confirmed：S6 是人工门，必须由你确认飞书端验收通过后才能收尾。", **snapshot(sc)))
    record(sc, "pass", "S6_ACCEPTANCE", "用户确认验收通过")
    sc["status"] = "DONE"
    save_state(args.project_root, st)
    emit(envelope(True, "S6_ACCEPTANCE 验收确认，飞书通道打通完成（DONE）。业务推送（feishu-push）现已放行。", **snapshot(sc)))


def cmd_reset(st, args):
    if not args.yes:
        emit(envelope(False, "reset 需要 --yes 确认。"))
    save_state(args.project_root, fresh_state())
    emit(envelope(True, "状态已清空，回到 NOT_STARTED。"))


def main():
    ap = argparse.ArgumentParser(description="健身团队安装器状态机")
    sub = ap.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--project-root", required=True)

    p_status = sub.add_parser("status", parents=[common])
    p_next = sub.add_parser("next", parents=[common])
    p_next.add_argument("--pick", help="S3 多个单聊会话时指定目标 chat_id")
    p_complete = sub.add_parser("complete", parents=[common])
    p_complete.add_argument("--state", required=True)
    p_complete.add_argument("--confirmed", action="store_true")
    p_reset = sub.add_parser("reset", parents=[common])
    p_reset.add_argument("--yes", action="store_true")

    args = ap.parse_args()
    if not os.path.isdir(os.path.join(args.project_root, "fitness-team")):
        emit(envelope(False, f"项目根无效：{args.project_root} 下找不到 fitness-team 数据区。"))

    st = load_state(args.project_root)
    {"status": cmd_status, "next": cmd_next, "complete": cmd_complete,
     "reset": cmd_reset}[args.command](st, args)


if __name__ == "__main__":
    main()
