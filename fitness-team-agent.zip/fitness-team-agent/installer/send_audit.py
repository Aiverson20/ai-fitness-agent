# -*- coding: utf-8 -*-
"""发送审计与对账（M5）：把「绕过例程直调 lark-cli」从事后无据可查变成可机器发现。

背景（2026-09-07 实证）：一份当日日志 md 原件（file 消息）与一张计划卡由模型直调
`lark-cli im +messages-send` 发出，同时跳过了交付形态围栏、通道围栏与交付状态机三道代码约束。
交付状态机只管得住走 `push.py` 的路径，管不住「宿主把对话回复自动卡片化」与「直调 lark-cli」
两类旁路（铁律 8.6 已诚实声明此边界）。本脚本补的正是这条边界上的**事后对账**。

数据来源两侧：
  1. 本地审计：`fitness-team/logs/send-audit.jsonl`，由 `push.py` 每次发送/更新成功后追加一行。
  2. 飞书实况：`lark-cli im +chat-messages-list` 拉取目标单聊在时间窗内的全部消息。
两侧按 message_id 对账：审计里没有、会话里却存在的机器人消息 = 未经例程发出。

两条实测得出的判定前提（2026-09-08 真实对账验证）：
  A. **lark-cli 返回渲染视图，不是原始卡片 JSON**：带 header 的规范卡片渲染成
     `<card title="..." subtitle="...">`，宿主自动卡片化的对话回复渲染成裸 `<card>`。
     所以「是否有 header」要检测渲染文本的 `<card title=`，dict 的 `header` 字段也一并认。
  B. **审计有覆盖起点**：`audit_coverage_from` 取最早一条审计的日期。早于起点（或审计为空）的
     消息属机制上线前的历史，**不能**拿「不在册」当违规依据——否则会把当年合规推送的规范卡片
     全误报成 alert。历史窗口只按形态与内容判定：形态违规仍 alert，形态合规降 info(pre_audit)，
     内容级疑点（无 header 自动卡片化、长文本/特征词）仍 review。

分级（对齐 9-07 的三条真实物证 [25] / [26] / [22]）：
  alert  明确违规，必须处理——
         · 非白名单形态（file / post / media / audio / sticker）：铁律 8.2 物理禁发项
           （9-07 [26] 即此型，与审计在册性无关，历史消息同样报）
         · 带 header 的规范 Card 2.0 却不在审计里（且在覆盖期内）：绕过 push.py 直发的产物卡
         · image 不在审计里（且在覆盖期内）：未经例程的图片消息
  review 疑似违规，需人工判定——升级要有**结构证据**（三条强判据任一成立）：
         ① 正文含 markdown 表格分隔符 `|---`；② 超长（卡 600 / 文本 160 字符）；
         ③ 命中产物特征词 >= 3 个。只按「命中特征词」会误报——9-07 实测合规的过程确认
         （"把加餐补充更新到饮食报告，稍等～"）也顺带提到产物字样，故加结构判据。
         · interactive 无 header 且含产物结构：宿主把对话回复自动卡片化并内嵌产物全文
           （9-07 [25] 即此型，含表格），违反铁律 8.2 第 4 条单条产物消息原则
         · 含产物结构的 text 消息（9-07 [22] 即此型）：疑似把产物内容塞进对话回复
         · 发送方无法判定：判定启发式失效，需按 raw_sender 调优
  info   合规或无关——短文本过程性确认、无表格结构的短裸卡（宿主自动卡片化的过程确认、
         系统合并提示；顺带提及产物字样的也在 reason 里留痕但不定性）、系统消息、
         已撤回消息、审计在册的消息、
         以及覆盖期前形态合规的历史消息（标 pre_audit=true）

子命令：
  reconcile   拉飞书实况与审计对账，输出分级信封（有 alert 时 ok=false）
  list        离线查看审计条目（--date / --product 过滤）

读消息一律 `--as user`：lark-cli `strict mode is "user"` 下 `--as bot` 的读命令被拒
（铁律 8.6 环境事实，2026-09-07 实测）；`push.py` 的 `--as bot` 写路径不受影响。
本脚本只读不写，不注入任何凭证，也不修改任何数据文件。

离线测试：`reconcile --offline-file <messages.json>` 跳过 lark-cli，直接对给定消息列表分级。
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import glob
from datetime import datetime, timedelta

AUDIT_RELPATH = os.path.join("fitness-team", "logs", "send-audit.jsonl")
CHANNEL_RELPATH = os.path.join("fitness-team", "channel.json")

ALLOWED_MSG_TYPES = ("text", "image", "interactive")   # 铁律 8.2 消息形态白名单
FORBIDDEN_MSG_TYPES = ("file", "post", "media", "audio", "sticker")

LONG_TEXT_THRESHOLD = 160     # 超过此长度的 text 视为疑似塞产物内容
LONG_CARD_THRESHOLD = 600     # 卡片序列化长度超过此值视为疑似产物全文
# 产物特征词：命中即提高「对话回复复述了产物」的嫌疑
PRODUCT_HINTS = ("评分", "得分", "分（", "今日饮食报告", "饮食报告", "晚间汇报", "训练计划",
                 "档案卡", "复盘", "蛋白质", "千卡", "kcal", "| ---", "|---", "勾销")
# 产物内嵌的「结构铁证」：markdown 表格分隔符。真产物全文都带表格，过程性确认不会带。
TABLE_MARKERS = ("|---", "| ---")
# 命中特征词数达到此值，即使没有表格也按疑似产物全文处理
STRONG_HINT_COUNT = 3


# ------------------------------------------------------------------ 基础工具

def envelope_ok(message, **extra):
    e = {"ok": True, "message": message}
    e.update(extra)
    return e


def envelope_err(code, message, err_type="audit", **extra):
    err = {"type": err_type, "code": code, "message": message}
    err.update(extra)
    return {"ok": False, "error": err}


def emit(env, exit_code=None):
    print(json.dumps(env, ensure_ascii=False, indent=2))
    if exit_code is None:
        exit_code = 0 if env.get("ok") else 1
    sys.exit(exit_code)


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return default


def find_cli():
    """定位 lark-cli（与 push.py 同一策略）：PATH 优先，飞书插件目录兜底。"""
    exe = shutil.which("lark-cli")
    if exe:
        return exe
    home = os.path.expanduser("~")
    pats = [
        os.path.join(home, ".trae-cn", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
        os.path.join(home, ".trae", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
    ]
    cands = []
    for p in pats:
        cands.extend(glob.glob(p))
    return sorted(cands)[-1] if cands else None


# ------------------------------------------------------------------ 审计日志

def read_audit(project_root, date=None, product=None):
    """读审计 jsonl，返回 (entries, missing_file_bool, bad_lines)。"""
    path = os.path.join(project_root, AUDIT_RELPATH)
    if not os.path.isfile(path):
        return [], True, 0
    entries, bad = [], 0
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    bad += 1
                    continue
                if date and rec.get("date") != date:
                    continue
                if product and rec.get("product") != product:
                    continue
                entries.append(rec)
    except OSError:
        return [], True, 0
    return entries, False, bad


# ------------------------------------------------------------------ 拉飞书消息

def day_window(date_str):
    """把 YYYY-MM-DD 展开成本地时区的整日窗口（含首尾秒）。"""
    d = datetime.strptime(date_str, "%Y-%m-%d")
    start = d.replace(hour=0, minute=0, second=0).astimezone()
    end = d.replace(hour=23, minute=59, second=59).astimezone()
    return start.isoformat(timespec="seconds"), end.isoformat(timespec="seconds")


def extract_messages(payload):
    """从 lark-cli 返回里递归找消息数组（不同版本可能在顶层 / data 段）。"""
    if isinstance(payload, list):
        return payload if payload and isinstance(payload[0], dict) else []
    if not isinstance(payload, dict):
        return []
    for key in ("messages", "items", "data"):
        v = payload.get(key)
        if isinstance(v, list):
            return v
        if isinstance(v, dict):
            got = extract_messages(v)
            if got:
                return got
    return []


def fetch_chat_messages(exe, chat_id, start, end, identity="user", extra_args=None):
    """调 lark-cli 拉会话消息。返回 (messages, envelope_or_None)。

    `--json` 与 `--format json` 两种写法都试一次：push.py 实证 `--json` 可用，
    技能文档写的是 `--format json`，版本差异在此吸收，不靠调用方猜。
    """
    base = [exe, "im", "+chat-messages-list",
            "--as", identity,
            "--chat-id", chat_id,
            "--start", start,
            "--end", end,
            "--order", "asc",
            "--page-all",
            "--no-reactions"]
    if extra_args:
        base.extend(extra_args)
    tried = []
    for flag in ("--json", "--format"):
        argv = base + ([flag] if flag == "--json" else [flag, "json"])
        if exe.lower().endswith((".cmd", ".bat")):
            argv = ["cmd", "/c"] + argv
        r = subprocess.run(argv, capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        tried.append({"argv_flag": flag, "returncode": r.returncode,
                      "stderr_tail": (r.stderr or "")[-400:]})
        out = (r.stdout or "").strip()
        i = out.find("{")
        j = out.find("[")
        cut = min([x for x in (i, j) if x >= 0] or [0])
        payload = None
        if out[cut:]:
            try:
                payload = json.loads(out[cut:])
            except json.JSONDecodeError:
                payload = None
        msgs = extract_messages(payload) if payload is not None else []
        if msgs:
            return msgs, None
        if payload is not None and (payload.get("ok") is False or
                                    (isinstance(payload.get("code"), int) and payload["code"] != 0)):
            return [], envelope_err(
                "fetch_failed",
                "拉取飞书会话消息失败（flag=%s）：%s"
                % (flag, json.dumps(payload, ensure_ascii=False)[:800]),
                err_type="environment", tried=tried)
    # 两轮都没拿到消息：可能是当天确实没消息，也可能是参数/权限问题，如实交回证据
    return [], envelope_err(
        "fetch_empty",
        "未能从飞书取到消息（时间窗 %s ~ %s，chat_id=%s）。可能当日确无消息，"
        "也可能是权限（im:message:readonly / im:chat:read）或参数问题。"
        "两轮调用的返回如下，请据此判定，不要当作「无违规」。"
        % (start, end, chat_id),
        err_type="environment", tried=tried)


# ------------------------------------------------------------------ 消息解析

def parse_content(msg):
    c = msg.get("content")
    if isinstance(c, dict):
        return c
    if isinstance(c, str):
        try:
            return json.loads(c)
        except json.JSONDecodeError:
            return {"_raw": c}
    return {}


def sender_side(msg, app_id):
    """判定发送方：bot / user / unknown（启发式，判不出就归 unknown 交人工）。"""
    s = msg.get("sender") or {}
    if not isinstance(s, dict):
        s = {}
    st = str(s.get("sender_type") or s.get("type") or msg.get("sender_type") or "").lower()
    if st in ("app", "bot"):
        return "bot", "sender_type=%s" % st
    if st in ("user", "human"):
        return "user", "sender_type=%s" % st
    if msg.get("open_bot_id") or s.get("open_bot_id"):
        return "bot", "open_bot_id 存在"
    sid = str(s.get("id") or s.get("sender_id") or msg.get("sender_id") or "")
    if sid.startswith("cli_") or (app_id and sid == app_id):
        return "bot", "sender_id=%s 匹配应用" % sid
    if sid.startswith("ou_") or sid.startswith("on_"):
        return "user", "sender_id=%s 为用户 open_id" % sid
    return "unknown", "sender_type=%r sender_id=%r" % (st, sid)


def card_has_header(content):
    """规范 Card 2.0 带 header；宿主自动卡片化的对话回复没有 header。

    实测（2026-09-07 真实对账）：lark-cli `im +chat-messages-list` 返回的 content 是**渲染视图**
    而非原始卡片 JSON —— 带 header 的卡片渲染成 `<card title="..." subtitle="...">`，
    宿主自动卡片化的对话回复渲染成裸 `<card>`（无 title 属性）。故两种形态都要认。
    """
    if isinstance(content, dict):
        if isinstance(content.get("header"), dict):
            return True
        for key in ("card", "body"):
            sub = content.get(key)
            if isinstance(sub, dict) and isinstance(sub.get("header"), dict):
                return True
        raw = content.get("_raw")
        if isinstance(raw, str):
            return _rendered_card_has_title(raw)
        return False
    if isinstance(content, str):
        return _rendered_card_has_title(content)
    return False


def _rendered_card_has_title(raw):
    s = raw.lstrip()
    if not s.startswith("<card"):
        return False
    head = s[:s.find(">") + 1] if ">" in s else s
    return "title=" in head


def msg_date(msg):
    """取消息日期（YYYY-MM-DD）。lark-cli 实测返回 'YYYY-MM-DD HH:MM'，也兼容毫秒时间戳。"""
    ct = msg.get("create_time")
    if isinstance(ct, str) and len(ct) >= 10 and ct[4] == "-":
        return ct[:10]
    try:
        ts = int(ct)
    except (TypeError, ValueError):
        return None
    if ts > 10 ** 12:      # 毫秒
        ts //= 1000
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
    except (OSError, OverflowError, ValueError):
        return None


def audit_coverage_from(entries):
    """审计覆盖起点：最早一条审计的日期。None = 完全没有审计覆盖（机制上线前的历史数据）。

    没有覆盖就不能拿「不在册」当违规依据——那会把审计机制上线前**合规**推送的卡片
    全部误报成 alert。此时只按**形态**判定：形态违规（file/post/media）仍报 alert
    （与在册性无关，铁律 8.2 物理禁发），形态合规的降为 info 并标 pre_audit。
    """
    dates = [str(e.get("time", ""))[:10] for e in entries if e.get("time")]
    dates = [d for d in dates if len(d) == 10]
    return min(dates) if dates else None


def preview(msg, content, limit=180):
    mt = msg.get("msg_type")
    if mt == "text":
        txt = str(content.get("text") or content.get("_raw") or "")
    elif mt == "interactive":
        txt = json.dumps(content, ensure_ascii=False)
    elif mt == "image":
        txt = "image_key=%s" % (content.get("image_key") or "")
    else:
        txt = json.dumps(content, ensure_ascii=False)
    txt = " ".join(txt.split())
    return txt[:limit] + ("…" if len(txt) > limit else "")


def brief(msg, content, side, reason, hints=None, pre_audit=False):
    return {
        "message_id": msg.get("message_id"),
        "msg_type": msg.get("msg_type"),
        "create_time": msg.get("create_time"),
        "sender_side": side,
        "reason": reason,
        "hit_hints": hints or [],
        "deleted": bool(msg.get("deleted")),
        "pre_audit": bool(pre_audit),
        "content_preview": preview(msg, content),
    }


def classify(msg, audited_ids, app_id, coverage=None):
    """给一条消息定级。返回 (level, brief_dict)。level ∈ alert/review/info/routed。

    coverage = 审计覆盖起点日期（`audit_coverage_from`），None 表示审计日志里一条都没有。
    早于 coverage 的消息属于「审计机制上线前的历史」，此时**不能**拿「不在册」当违规依据
    （否则把当年合规推送的规范卡片全误报成 alert），只按**形态与内容**判定：
      - 形态违规（file/post/media/audio/sticker、未知类型）→ 仍 alert（铁律 8.2 物理禁发，与在册性无关）；
      - 形态合规但不在册（带 header 规范卡、image）→ 降为 info 并标 pre_audit=True；
      - 内容级疑点（无 header 自动卡片化、长文本/含产物特征词）→ 仍 review（这类与在册性无关，
        是铁律 8.2 第 4 条的违反嫌疑，历史数据同样要人工核对）。
    """
    mid = msg.get("message_id")
    mt = str(msg.get("msg_type") or "").lower()
    content = parse_content(msg)
    side, side_reason = sender_side(msg, app_id)

    if mid in audited_ids:
        return "routed", brief(msg, content, side, "在审计日志中（经 push.py 例程发出）")

    if side == "user":
        return "info", brief(msg, content, side, "用户本人发的消息，不属团队交付（%s）" % side_reason)

    if msg.get("deleted"):
        return "info", brief(msg, content, side, "消息已撤回，不计违规")

    if mt == "system":
        return "info", brief(msg, content, side, "系统消息")

    if side == "unknown":
        return "review", brief(msg, content, side,
                               "发送方无法判定（%s），请据 raw_sender 调优判定启发式" % side_reason)

    # 审计覆盖起点之前（或完全无审计）→ 历史消息，不按「不在册」定违规
    d = msg_date(msg)
    pre_audit = (coverage is None) or (d is not None and d < coverage)
    hist = "审计机制上线前的历史消息（早于覆盖起点 %s），不按「不在册」定违规" % (coverage or "无审计数据")

    # 以下均为机器人发出、且不在审计中 → 未经例程
    if mt in FORBIDDEN_MSG_TYPES:
        return "alert", brief(msg, content, side,
                              "非白名单形态 %s：铁律 8.2 物理禁发项，且绕过了 push.py 的形态围栏"
                              "（形态违规与审计在册性无关，历史消息同样报）" % mt,
                              pre_audit=pre_audit)
    if mt not in ALLOWED_MSG_TYPES:
        return "alert", brief(msg, content, side,
                              "非白名单形态 %s（未知类型）：未经例程发出" % mt,
                              pre_audit=pre_audit)
    if mt == "image":
        if pre_audit:
            return "info", brief(msg, content, side, hist + "；形态合规（image）", pre_audit=True)
        return "alert", brief(msg, content, side,
                              "未经例程的图片消息：图片类产物必须由 push.py 发出并留审计")
    if mt == "interactive":
        if card_has_header(content):
            if pre_audit:
                return "info", brief(msg, content, side, hist + "；形态合规（带 header 的规范卡片）",
                                     pre_audit=True)
            return "alert", brief(msg, content, side,
                                  "带 header 的规范卡片却不在审计中：绕过 push.py 直发的产物卡")
        blob = json.dumps(content, ensure_ascii=False)
        hints = [h for h in PRODUCT_HINTS if h in blob]
        has_table = any(m in blob for m in TABLE_MARKERS)
        # 无 header 的裸卡 = 宿主把对话回复自动卡片化（飞书端不可避免，本身不违规）。
        # 定「产物内嵌」要有结构证据，不能只靠特征词：9-07 实测发现合规的过程性确认
        # （"把加餐补充更新到饮食报告，稍等～"）也会顺带提到产物字样，若只按特征词判定
        # 就会把 21:32 / 21:35 两条合规确认误报成 review，稀释真违规（5 条产物全文裸卡）。
        # 三条强判据任一成立才升 review：① 含 markdown 表格；② 超长；③ 特征词 >= 3 个。
        strong = has_table or len(blob) > LONG_CARD_THRESHOLD or len(hints) >= STRONG_HINT_COUNT
        if not strong:
            note = ("无 header 短卡片（%d 字符、无表格结构、特征词 %d 个）：宿主自动卡片化的"
                    "过程性确认或系统合并提示，形态合规" % (len(blob), len(hints)))
            if hints:
                note += "；顺带提及 %s，但无表格/明细结构，不按「产物内嵌」定性" % "/".join(hints[:3])
            return "info", brief(msg, content, side, note, hints, pre_audit=pre_audit)
        why = ("interactive 无 header 且含产物结构，疑似宿主把对话回复自动卡片化并内嵌产物内容"
               "（铁律 8.2 第 4 条：飞书端对话回复只能是极短过程性确认）；长度 %d 字符%s%s"
               % (len(blob),
                  "、含 markdown 表格" if has_table else "",
                  ("、命中产物特征词 " + "/".join(hints[:5])) if hints else ""))
        if pre_audit:
            why += "；%s，内容级疑点仍需人工核对" % hist
        return "review", brief(msg, content, side, why, hints, pre_audit=pre_audit)
    # text
    txt = str(content.get("text") or content.get("_raw") or "")
    hints = [h for h in PRODUCT_HINTS if h in txt]
    has_table = any(m in txt for m in TABLE_MARKERS)
    strong = has_table or len(txt) > LONG_TEXT_THRESHOLD or len(hints) >= STRONG_HINT_COUNT
    if strong:
        why = ("含产物结构的对话回复（%d 字符%s%s），疑似把产物内容写进回复"
               % (len(txt),
                  "、含 markdown 表格" if has_table else "",
                  ("，命中 " + "/".join(hints[:5])) if hints else ""))
        if pre_audit:
            why += "；%s，内容级疑点仍需人工核对" % hist
        return "review", brief(msg, content, side, why, hints, pre_audit=pre_audit)
    note = "短文本过程性确认（%d 字符、无表格结构），合规" % len(txt)
    if hints:
        note += "；顺带提及 %s，不按「产物内嵌」定性" % "/".join(hints[:3])
    return "info", brief(msg, content, side, note, hints, pre_audit=pre_audit)


# ------------------------------------------------------------------ 子命令

def cmd_reconcile(a):
    channel = load_json(os.path.join(a.project_root, CHANNEL_RELPATH), {}) or {}
    chat_id = a.chat_id or channel.get("target_chat_id")
    app_id = channel.get("app_id")
    date = a.date or datetime.now().strftime("%Y-%m-%d")
    end_date = a.end or date

    entries, missing, bad = read_audit(a.project_root)
    audited_ids = set(e.get("message_id") for e in entries if e.get("message_id"))
    coverage = audit_coverage_from(entries)

    if a.offline_file:
        payload = load_json(a.offline_file)
        if payload is None:
            emit(envelope_err("offline_file_unreadable",
                              "离线消息文件读不出 JSON：%s" % a.offline_file,
                              err_type="environment"))
        msgs = extract_messages(payload)
        source = "offline_file"
    else:
        if not chat_id:
            emit(envelope_err("no_chat_id",
                              "channel.json 里没有 target_chat_id，也未指定 --chat-id，无法对账。"
                              "先按铁律 9.5 打通通道（channel-setup），或显式传 --chat-id。"))
        exe = find_cli()
        if not exe:
            emit(envelope_err("no_lark_cli",
                              "找不到 lark-cli：PATH 与飞书插件目录均无该可执行文件。",
                              err_type="environment"))
        start, end = day_window(date)
        _, end2 = day_window(end_date)
        msgs, err = fetch_chat_messages(exe, chat_id, start, end2, identity=a.identity)
        if err:
            err["error"].update({"audit_entries": len(entries), "audit_message_ids": len(audited_ids)})
            emit(err)
        source = "lark-cli im +chat-messages-list"

    buckets = {"alert": [], "review": [], "info": [], "routed": []}
    for m in msgs:
        if not isinstance(m, dict):
            continue
        level, b = classify(m, audited_ids, app_id, coverage)
        buckets[level].append(b)

    # 反向核对：审计在册但会话里找不到（撤回、时间窗外、或 message_id 解析失败）
    seen = set(str(m.get("message_id")) for m in msgs if isinstance(m, dict))
    window_entries = [e for e in entries
                      if (e.get("date") in (date, end_date)) or
                      (str(e.get("time", ""))[:10] >= date and str(e.get("time", ""))[:10] <= end_date)]
    not_found = [e for e in window_entries if e.get("message_id") and e["message_id"] not in seen]

    all_briefs = buckets["alert"] + buckets["review"] + buckets["info"] + buckets["routed"]
    result = {
        "source": source,
        "chat_id": chat_id,
        "window": {"date": date, "end": end_date},
        "identity": None if a.offline_file else a.identity,
        "message_count": len(msgs),
        "bot_message_count": sum(1 for x in all_briefs if x.get("sender_side") == "bot"),
        "routed_count": len(buckets["routed"]),
        "alert_count": len(buckets["alert"]),
        "review_count": len(buckets["review"]),
        "info_count": len(buckets["info"]),
        "pre_audit_count": sum(1 for lvl in ("alert", "review", "info")
                               for x in buckets[lvl] if x.get("pre_audit")),
        "unknown_sender_count": sum(1 for lvl in ("alert", "review", "info")
                                    for x in buckets[lvl] if x.get("sender_side") == "unknown"),
        "audit_coverage_from": coverage,
        "audit_entries_total": len(entries),
        "audit_message_ids": len(audited_ids),
        "audit_missing_file": missing,
        "audit_bad_lines": bad,
        "audit_not_found_in_chat": [
            {"message_id": e.get("message_id"), "product": e.get("product"),
             "date": e.get("date"), "action": e.get("action"), "time": e.get("time")}
            for e in not_found],
        "alerts": buckets["alert"],
        "reviews": buckets["review"],
        "infos": buckets["info"],
    }

    if buckets["alert"]:
        form_ids = [x.get("message_id") for x in buckets["alert"]
                    if str(x.get("msg_type") or "").lower() not in ALLOWED_MSG_TYPES]
        bypass_ids = [x.get("message_id") for x in buckets["alert"]
                      if str(x.get("msg_type") or "").lower() in ALLOWED_MSG_TYPES]
        parts = ["对账发现 %d 条违规消息（alert 级），message_id 已列出。" % len(buckets["alert"])]
        if form_ids:
            parts.append("其中 %d 条是**非白名单形态**（file/post/media/audio/sticker 等）："
                         "铁律 8.2 物理禁发项，与审计在册性无关，历史消息同样报。id=%s。"
                         % (len(form_ids), ", ".join(str(i) for i in form_ids)))
        if bypass_ids:
            parts.append("其中 %d 条是**形态合规却绕过例程**（未经 push.py，同时跳过形态围栏、"
                         "通道围栏与交付状态机，铁律 9.4.2）。id=%s。"
                         % (len(bypass_ids), ", ".join(str(i) for i in bypass_ids)))
        if not coverage:
            parts.append("注意：审计日志为空（覆盖起点未知，机制上线前的窗口），本次**只按形态**定 alert，"
                         "未拿「不在册」当违规依据；形态合规的历史消息已降为 info(pre_audit)。")
        parts.append("处理方式：核对内容是否违反铁律 8.2，必要时撤回该消息，"
                     "并把该产物改走 feishu-push 例程重新交付；不要原样重发。")
        result["ok"] = False
        result["error"] = {
            "type": "audit",
            "code": "unrouted_messages",
            "message": "".join(parts),
            "alert_message_ids": [x.get("message_id") for x in buckets["alert"]],
            "form_violation_ids": form_ids,
            "bypass_ids": bypass_ids,
        }
        emit(result)

    if buckets["review"]:
        result["ok"] = True
        result["warning"] = {
            "code": "messages_need_review",
            "message": "无 alert 级违规，但有 %d 条消息需人工判定（疑似对话回复复述产物 / "
                       "发送方无法判定）。铁律 8.2 第 4 条要求飞书端对话回复只能是极短过程性确认，"
                       "请逐条核对 content_preview。" % len(buckets["review"]),
            "review_message_ids": [x.get("message_id") for x in buckets["review"]],
        }
        emit(result)

    result["ok"] = True
    result["message"] = "对账通过：窗口内 %d 条消息，%d 条经例程在册，无未登记消息。" % (
        len(msgs), len(buckets["routed"]))
    emit(result)


def cmd_list(a):
    entries, missing, bad = read_audit(a.project_root, date=a.date, product=a.product)
    if missing:
        emit(envelope_ok("审计文件尚未生成（%s），无发送记录。" % AUDIT_RELPATH,
                         count=0, path=AUDIT_RELPATH, entries=[]))
    emit(envelope_ok("审计条目 %d 条" % len(entries), count=len(entries),
                     path=AUDIT_RELPATH, bad_lines=bad,
                     date=a.date, product=a.product, entries=entries))


def main():
    ap = argparse.ArgumentParser(description="发送审计与对账（M5）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("reconcile", help="拉飞书会话消息与审计日志对账，分级报警")
    p.add_argument("--project-root", required=True)
    p.add_argument("--date", help="YYYY-MM-DD，默认今天")
    p.add_argument("--end", help="窗口结束日期，默认同 --date")
    p.add_argument("--chat-id", help="覆盖 channel.json 的 target_chat_id")
    p.add_argument("--as", dest="identity", default="user", choices=["user", "bot"],
                   help="读消息身份，默认 user（strict mode 下 bot 的读命令被拒，铁律 8.6）")
    p.add_argument("--offline-file", help="离线测试：直接读该 JSON 作为消息列表，跳过 lark-cli")
    p.set_defaults(func=cmd_reconcile)

    p = sub.add_parser("list", help="离线查看审计条目")
    p.add_argument("--project-root", required=True)
    p.add_argument("--date", help="YYYY-MM-DD 过滤")
    p.add_argument("--product", help="产物类型过滤")
    p.set_defaults(func=cmd_list)

    a = ap.parse_args()
    a.func(a)


if __name__ == "__main__":
    main()
