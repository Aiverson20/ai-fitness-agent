# -*- coding: utf-8 -*-
"""相册归档例程（铁律 3 / 铁律 4 的代码化）：训练照与餐食照统一经本脚本落盘。

背景（logs/troubleshoot-2026-09-07-feishu.md 问题 1 根因 2 / 根因 4）：
  - 归档此前纯靠 prompt，已实证会漏做（完好的训练照没落盘）；
  - 照片被撤回 / 损坏时，模型会回退到「图片读取失败 → 请用户文字描述」的通用兜底，
    把技术失败暴露给用户。本脚本把该触发点堵死：源文件缺失 / 为空一律返回
    `src_missing` 信封，调用方**静默跳过**，不提、不解释、不以此索要文字。

规则：
  - 目录层级强制 `YYYY/MM/`（训练 `albums/training/`，餐食 `albums/meals/`），自动创建；
  - 命名：训练 `YYYY-MM-DD.jpg`，餐食 `YYYY-MM-DD-<meal>.jpg`；同日同类型多张自动加
    `_2` / `_3` 序号，**永不覆盖、永不删除**已有文件；
  - 复制后校验目标存在且字节数与源一致，校验不过返回 `verify_failed`；
  - 只接受常见图片扩展名，其他文件返回 `not_image`；
  - 信封只含**数据区相对路径**（如 `fitness-team/albums/training/2026/09/2026-09-08.jpg`），
    可直接写入当日日志，不含本地绝对路径（铁律 8.2 正文禁本地路径）。

子命令：
  archive   归档一张照片（默认动作，可省略子命令名）
  check     盘点某日某类相册的文件数（审计 / 日志回执核对用）

信封风格与 delivery.py / push.py 一致：成功 {"ok": true, ...}，
失败 {"ok": false, "error": {"type": "archive", "code": ..., "message": ...}}。
"""
import argparse
import json
import os
import shutil
import sys
from datetime import datetime

MEALS = ("breakfast", "lunch", "dinner")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".heic")


# ------------------------------------------------------------------ 基础工具

def envelope_ok(message, **extra):
    e = {"ok": True, "message": message}
    e.update(extra)
    return e


def envelope_err(code, message, **extra):
    err = {"type": "archive", "code": code, "message": message}
    err.update(extra)
    return {"ok": False, "error": err}


def emit(env, exit_code=None):
    print(json.dumps(env, ensure_ascii=False))
    if exit_code is None:
        exit_code = 0 if env.get("ok") else 1
    sys.exit(exit_code)


def valid_date(s):
    try:
        datetime.strptime(s, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def rel_to_root(project_root, path):
    """返回数据区相对路径（正斜杠），供日志与信封使用。"""
    return os.path.relpath(path, project_root).replace(os.sep, "/")


def album_dir(project_root, type_, date):
    y, m = date.split("-")[0], date.split("-")[1]
    return os.path.join(project_root, "fitness-team", "albums",
                        "training" if type_ == "training" else "meals", y, m)


def unique_target(dirpath, stem, ext):
    """同名不覆盖：`stem.ext` 存在则 `stem_2.ext`、`stem_3.ext` 顺延。"""
    candidate = os.path.join(dirpath, stem + ext)
    n = 2
    while os.path.exists(candidate):
        candidate = os.path.join(dirpath, "%s_%d%s" % (stem, n, ext))
        n += 1
    return candidate


# ------------------------------------------------------------------ archive

def cmd_archive(a):
    if not valid_date(a.date):
        emit(envelope_err("bad_date", "日期格式必须是 YYYY-MM-DD，收到 %r。" % a.date))
    if a.type == "meal" and a.meal not in MEALS:
        emit(envelope_err("missing_meal",
                          "餐食照归档必须带 --meal（breakfast / lunch / dinner），收到 %r。" % a.meal))

    src = os.path.abspath(a.src)
    # 静默分支（根因 2 的堵点）：源缺失 / 不可读 / 为空 → src_missing，
    # 调用方跳过这张照片即可，不得向用户提及、不得以此索要文字汇报。
    if not os.path.isfile(src):
        emit(envelope_err("src_missing",
                          "源文件不存在或不可读，本张跳过。这是定义好的静默分支："
                          "不向用户提及照片缺失 / 被撤回，不以此索要文字汇报，"
                          "其余流程照常（无照不扣分，铁律 3）。",
                          src=a.src))
    if os.path.getsize(src) == 0:
        emit(envelope_err("src_missing",
                          "源文件为 0 字节（损坏或被撤回的空壳），本张跳过。"
                          "静默处理，不向用户提及，其余流程照常。",
                          src=a.src))

    ext = os.path.splitext(src)[1].lower()
    if ext not in IMAGE_EXTS:
        emit(envelope_err("not_image",
                          "只归档图片文件（%s），收到扩展名 %r。非图片一律不归档、不发回。"
                          % ("/".join(IMAGE_EXTS), ext)))

    dirpath = album_dir(a.project_root, a.type, a.date)
    os.makedirs(dirpath, exist_ok=True)
    stem = a.date if a.type == "training" else "%s-%s" % (a.date, a.meal)
    target = unique_target(dirpath, stem, ext)

    try:
        shutil.copy2(src, target)
    except OSError as e:
        emit(envelope_err("copy_failed", "复制失败：%s" % e, src=a.src))

    # 复制后校验：存在且字节数一致
    if not os.path.isfile(target) or os.path.getsize(target) != os.path.getsize(src):
        emit(envelope_err("verify_failed",
                          "复制后校验未通过（目标缺失或字节数不一致），"
                          "请检查磁盘空间与目录权限后重试一次；仍失败则如实告知用户。",
                          target=rel_to_root(a.project_root, target)))

    emit(envelope_ok(
        "已归档。把相对路径写入当日日志对应章节作为归档回执；"
        "照片不分析、不点评、不发回（铁律 3 / 4）。",
        type=a.type,
        date=a.date,
        meal=a.meal if a.type == "meal" else None,
        relative_path=rel_to_root(a.project_root, target),
        bytes=os.path.getsize(target),
    ))


# ------------------------------------------------------------------ check

def cmd_check(a):
    if not valid_date(a.date):
        emit(envelope_err("bad_date", "日期格式必须是 YYYY-MM-DD，收到 %r。" % a.date))
    dirpath = album_dir(a.project_root, a.type, a.date)
    files = []
    if os.path.isdir(dirpath):
        files = sorted(f for f in os.listdir(dirpath)
                       if f.startswith(a.date) and os.path.isfile(os.path.join(dirpath, f)))
    emit(envelope_ok(
        "%s 相册 %s 共 %d 个文件。" % (a.date, a.type, len(files)),
        type=a.type, date=a.date, count=len(files), files=files,
        relative_dir=rel_to_root(a.project_root, dirpath),
    ))


# ------------------------------------------------------------------ CLI

def main():
    p = argparse.ArgumentParser(description="相册归档例程（训练照 / 餐食照）")
    sub = p.add_subparsers(dest="cmd")

    pa = sub.add_parser("archive", help="归档一张照片")
    pa.add_argument("--project-root", required=True)
    pa.add_argument("--type", required=True, choices=("training", "meal"))
    pa.add_argument("--date", required=True, help="YYYY-MM-DD（照片所属日期，不是执行日期）")
    pa.add_argument("--src", required=True, help="源图片路径（飞书端通常在会话工作区 .trae\\im-files\\）")
    pa.add_argument("--meal", default=None, help="type=meal 时必填：breakfast / lunch / dinner")
    pa.set_defaults(func=cmd_archive)

    pc = sub.add_parser("check", help="盘点某日某类相册文件数")
    pc.add_argument("--project-root", required=True)
    pc.add_argument("--type", required=True, choices=("training", "meal"))
    pc.add_argument("--date", required=True)
    pc.set_defaults(func=cmd_check)

    a = p.parse_args()
    if not getattr(a, "func", None):
        p.print_help()
        sys.exit(2)
    a.project_root = os.path.abspath(a.project_root)
    a.func(a)


if __name__ == "__main__":
    main()
