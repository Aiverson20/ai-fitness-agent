# -*- coding: utf-8 -*-
"""交付状态机（铁律 8.6）：白名单产物「先落盘 → 再推送 → 不重推 → 只改同一张卡」。

状态文件 `fitness-team/delivery-state.json` 只由本例程与 `push.py` 写入，
**禁止手工编辑**（与 `install-state.json` 同规）。

状态序列：DRAFT → LOGGED → PUSHED → CLOSED
  DRAFT    实例已建、产物尚未写入本地数据区（保留态，本例程不主动产生）
  LOGGED   产物已落本地文件（当日日志 / 档案 / 计划），允许推送
  PUSHED   已由 push.py 发出，message_id 已回写；再推一律拒发（duplicate），
           修正走 `push.py --update` 原地更新同一张卡片，不新发消息
  CLOSED   该实例交付归档，不再接受推送

子命令：
  log           登记落盘（自动取序号；已有未推送实例则复用，避免重试撑大序号）
  query         **幂等判据**：定时任务用它判断「今天推过没有」，不看日志文本章节
  pending       列出已落盘未推送的实例
  list          列出实例（按日期）
  mark-pushed   置 PUSHED 并回写 message_id（push.py 内部调用）
  mark-updated  记录一次原地更新（push.py --update 内部调用）
  close         置 CLOSED
  products      打印产物类型白名单与拒登清单

产物类型白名单是铁律 8.1 的代码化：白名单外（尤其**训练打卡分数**）一律拒登、拒推，
状态机因此成为「分数不进飞书」的物理拦截，而不只是措辞约束。

产物节奏表 `PRODUCT_CADENCE` 区分「一天一件」（morning_plan / daily_report / cycle_review）
与「一天多件」（meal_photo 等）：一天一件的产物当日已有实例时 `log` 一律拒登（`--new` 无效），
修正只能 `push.py --update` 原地改同一张卡——把铁律 8.2 第 4 条「单条产物消息原则」
从措辞约束升级为代码约束，堵死「绕过 query 直接登记 seq=2 → 发出第二条」的口子。

信封风格与 push.py 的围栏一致：失败为 {"ok": false, "error": {...}}，
成功为 {"ok": true, ...}，调用方（模型）读 error.code 与 error.message 当场改道。
"""
import argparse
import json
import os
import sys
from datetime import datetime, timedelta

SCHEMA_VERSION = 1
STATES = ("DRAFT", "LOGGED", "PUSHED", "CLOSED")
RETENTION_DAYS = 180  # 超期实例自动清理，状态文件不无限增长

# ------------------------------------------------------------------ 产物白名单
# 铁律 8.1 推送范围白名单的代码化。新增产物类型必须同步铁律 8.1，不得只在代码里加。
PRODUCTS = {
    "profile_card": "档案卡（建档 / 重测 / 体重记录后的档案数据卡）",
    "training_plan": "训练计划卡（双周块计划卡，用户主动索取或计划变更时）",
    "morning_plan": "早间计划推送（09:00 定时任务：节点日两周计划卡 / 非节点日当日安排）",
    "plan_adjust": "计划调整确认卡（plan-adjust 产物）",
    "daily_report": "晚间汇报卡（daily-report 产物，含 23:00 兜底）",
    "meal_photo": "餐食照片识别结果（meal-photo-check 产物，一餐一实例）",
    "cycle_review": "周期复盘报告卡",
    "weight_receipt": "体重记录回执",
    "failure_notice": "通道 / 同步失败告知（铁律 8.4）",
}

# 明确拒登的产物类型：给定制化提示，避免调用方以为是拼写错误反复试。
BLOCKED_PRODUCTS = {
    "checkin_score": "训练打卡的分数与原因**只写入当日日志**，不推送飞书（铁律 8.1）。"
                     "分数是晚间汇报的素材，不是独立产物；飞书端连对话回复里也不得复述（铁律 8.2 第 4 条）。",
    "score": "同上：打卡分数只写当日日志，不推送（铁律 8.1）。",
    "checkin": "打卡结果只写当日日志，不单独推送（铁律 8.1）。",
    "move_library": "动作库变更属内部数据，不推送（铁律 8.1）。",
    "meal_plan": "配餐明细属内部数据，不推送（铁律 8.1）。",
    "data_file": "本地数据文件（json / md / html）不得发给用户（铁律 8.2）。",
}

# ------------------------------------------------------------------ 产物节奏表
# M5（M10 遗留防线）：区分「一天一件」与「一天多件」。
#   once  = 当日只允许一个交付实例，seq 恒为 1。已有实例时 `log` 一律拒登（含 --new 旁路）：
#           已发出的只能 push.py --update 原地改同一张卡，未发出的直接推原实例。
#           这一档堵的是「绕过 query 直接登记 → 发出第二条消息」的口子
#           （2026-09-07 晚间汇报险发第三条即此型）。
#   multi = 当日合法多件，序号自然递增（如三餐各一张识别结果卡）。
# 新产物立项时必须在此表登记节奏；节奏认定以铁律 8.1 / 12 为准，不得只改代码。
PRODUCT_CADENCE = {
    "morning_plan": "once",      # 09:00 定时任务每天只推一次（铁律 12）
    "daily_report": "once",      # 晚间汇报每天只交付一条，含 23:00 兜底（铁律 12）
    "cycle_review": "once",      # 一个周期一份复盘，同日不会有两份
    "meal_photo": "multi",       # 一餐一实例，一天最多三件（早/中/晚）
    "profile_card": "multi",     # 建档 / 重测 / 体重记录各自出卡，同日可能多次
    "weight_receipt": "multi",   # 同日多次记体重各出一条回执
    "training_plan": "multi",    # 用户主动索取 / 计划变更，同日可能多次
    "plan_adjust": "multi",      # 同日多次调整各出一条确认卡
    "failure_notice": "multi",   # 同日可能发生多次通道/同步失败，每次都要告知（铁律 8.4）
}
ONCE_PER_DAY = frozenset(p for p, c in PRODUCT_CADENCE.items() if c == "once")
MULTI_PER_DAY = frozenset(p for p, c in PRODUCT_CADENCE.items() if c == "multi")


# ------------------------------------------------------------------ 基础工具

def envelope_ok(message, **extra):
    e = {"ok": True, "message": message}
    e.update(extra)
    return e


def envelope_err(code, message, err_type="state", **extra):
    err = {"type": err_type, "code": code, "message": message}
    err.update(extra)
    return {"ok": False, "error": err}


def emit(env, exit_code=None):
    print(json.dumps(env, ensure_ascii=False))
    if exit_code is None:
        exit_code = 0 if env.get("ok") else 1
    sys.exit(exit_code)


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def today():
    return datetime.now().strftime("%Y-%m-%d")


def state_path(project_root):
    return os.path.join(project_root, "fitness-team", "delivery-state.json")


def fresh_state():
    return {"schema_version": SCHEMA_VERSION, "updated_at": None, "instances": {}}


def load_state(project_root):
    try:
        with open(state_path(project_root), encoding="utf-8") as f:
            st = json.load(f)
    except (OSError, json.JSONDecodeError):
        return fresh_state()
    if not isinstance(st.get("instances"), dict):
        st["instances"] = {}
    st.setdefault("schema_version", SCHEMA_VERSION)
    return st


def prune(st):
    """清掉超过保留期的实例（按实例日期，不按写入时间）。"""
    cutoff = (datetime.now() - timedelta(days=RETENTION_DAYS)).strftime("%Y-%m-%d")
    drop = [k for k, v in st["instances"].items() if str(v.get("date", "")) < cutoff]
    for k in drop:
        del st["instances"][k]
    return len(drop)


def save_state(project_root, st):
    st["updated_at"] = now_iso()
    prune(st)
    p = state_path(project_root)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=2)


def make_key(date, product, seq):
    return "%s|%s|%s" % (date, product, seq)


def parse_key(key):
    parts = str(key).split("|")
    if len(parts) != 3:
        return None
    return {"date": parts[0], "product": parts[1], "seq": parts[2]}


def instances_of(st, date=None, product=None):
    out = []
    for k, v in st["instances"].items():
        if date and v.get("date") != date:
            continue
        if product and v.get("product") != product:
            continue
        out.append(v)
    out.sort(key=lambda x: (str(x.get("date")), str(x.get("product")), int(x.get("seq") or 0)))
    return out


def next_seq(st, date, product):
    seqs = [int(v.get("seq") or 0) for v in instances_of(st, date, product)]
    return (max(seqs) + 1) if seqs else 1


def find_pending(st, date, product):
    """同日同产物、状态仍在 LOGGED/DRAFT 的实例（重试时复用，不撑大序号）。"""
    for v in instances_of(st, date, product):
        if v.get("state") in ("LOGGED", "DRAFT"):
            return v
    return None


def touch(inst, event, state=None, detail=""):
    if state:
        inst["state"] = state
    inst.setdefault("history", []).append(
        {"time": now_iso(), "event": event, "state": inst.get("state"), "detail": detail}
    )


def check_product(product):
    """产物类型围栏：白名单外拒登/拒推。返回 None 表示通过。"""
    if not product:
        return envelope_err(
            "missing_product",
            "缺少产物类型：交付状态机要求每次推送都声明 --product（白名单见铁律 8.1）。"
            "先 `python installer/delivery.py products --project-root <项目根>` 查看白名单，"
            "再 `log` 登记落盘、然后带 --product 推送。本条消息未发送。",
            allowed_products=sorted(PRODUCTS),
        )
    if product in BLOCKED_PRODUCTS:
        return envelope_err(
            "product_not_allowed",
            "推送被产物白名单拒绝：%s 不是可推送产物。%s 本条消息未发送（铁律 8.1）。"
            % (product, BLOCKED_PRODUCTS[product]),
            rejected_product=product,
            allowed_products=sorted(PRODUCTS),
        )
    if product not in PRODUCTS:
        return envelope_err(
            "product_unknown",
            "推送被产物白名单拒绝：%s 不在白名单内，可能是拼写错误或尚未立项的新产物。"
            "白名单：%s。新产物类型必须先写进铁律 8.1 再加进本例程，不得只在代码里加。"
            "本条消息未发送。" % (product, "、".join(sorted(PRODUCTS))),
            rejected_product=product,
            allowed_products=sorted(PRODUCTS),
        )
    return None


def check_once_per_day(st, date, product):
    """节奏围栏（M5 / M10 遗留）：「一天一件」产物当日已有实例时拒开新实例。

    返回 None 表示通过。堵的是「绕过 query 直接 log 出 seq=2 → 真发出第二条消息」的口子
    （2026-09-07 晚间汇报险发第三条即此型）。`--new` 旁路对本档产物同样无效。
    正常重试不受影响：未推送实例在上面 cmd_log 的复用分支就已 emit 返回，走不到这里。
    """
    if product not in ONCE_PER_DAY:
        return None
    items = instances_of(st, date, product)
    if not items:
        return None
    exist = items[-1]
    ekey = exist.get("key")
    estate = exist.get("state")
    mid = exist.get("message_id")
    extra = dict(product=product, date=date, cadence="once",
                 existing_key=ekey, existing_state=estate, existing_message_id=mid)
    if estate in ("PUSHED", "CLOSED") or exist.get("pushed_at"):
        return envelope_err(
            "once_per_day_pushed",
            "登记被产物节奏围栏拒绝：%s 的 %s 属「一天一件」产物，当日已交付过（实例 %s，状态 %s，"
            "message_id=%s），不得再开新实例。内容有错只能用 "
            "`push.py --update --product %s --date %s` 原地更新同一张卡片，"
            "不新发第二条消息（铁律 8.2 第 4 条单条产物消息原则）。"
            "怀疑状态不对就先 `python installer/delivery.py query --project-root <项目根> "
            "--date %s --product %s` 核对，不要绕过本围栏。"
            % (date, product, ekey, estate, mid, product, date, date, product),
            **extra
        )
    return envelope_err(
        "once_per_day_pending",
        "登记被产物节奏围栏拒绝：%s 的 %s 属「一天一件」产物，当日已有未推送实例 %s（状态 %s），"
        "不得再建新实例（--new 对本档产物无效）。直接把原实例推送出去：产物已落本地数据区就执行 "
        "`push.py --product %s --date %s`；尚未落盘就先写本地文件再推原实例。"
        "本档产物当日序号恒为 1。" % (date, product, ekey, estate, product, date),
        **extra
    )


# ------------------------------------------------------------------ 供 push.py 调用的 API

def resolve_for_push(project_root, product=None, date=None, seq=None, update=False):
    """推送前的状态检查（push.py 在通道围栏之后串这一道）。

    返回 (envelope, instance)：envelope["ok"] 为 False 时 instance 为 None，
    push.py 直接把 envelope 打印出去拒发。
    """
    date = date or today()
    perr = check_product(product)
    if perr:
        return perr, None

    st = load_state(project_root)
    if seq:
        inst = st["instances"].get(make_key(date, product, seq))
    else:
        # 未指定序号：--update 取最近一次已推送的实例，普通推送取待推送实例
        cands = instances_of(st, date, product)
        if update:
            pushed = [v for v in cands if v.get("state") == "PUSHED" and v.get("message_id")]
            inst = pushed[-1] if pushed else None
        else:
            pend = [v for v in cands if v.get("state") in ("LOGGED", "DRAFT")]
            if pend:
                inst = pend[0]
            else:
                # 没有待推送实例：把最近的 PUSHED / CLOSED 实例交给下面的状态分支报错，
                # PUSHED → duplicate（指引改 --update 原地改卡），CLOSED → closed
                # （「一天多件」指引建新实例；「一天一件」指引只能 --update），
                # 一个实例都没有 → missing_log。不能在这里直接判 missing_log，否则重复推送
                # 会被误报成「没登记」，模型就会去 log 新实例、真的发出第二条消息。
                pushed = [v for v in cands if v.get("state") == "PUSHED"]
                closed = [v for v in cands if v.get("state") == "CLOSED"]
                inst = pushed[-1] if pushed else (closed[-1] if closed else None)

    if inst is None:
        if update:
            return envelope_err(
                "nothing_to_update",
                "找不到可更新的消息：%s 的 %s 没有已推送（PUSHED）且带 message_id 的实例。"
                "只有已发出的卡片能原地更新；还没推过就先 log 登记再正常推送。"
                % (date, product),
                date=date, product=product,
            ), None
        cmd = ("python installer/delivery.py log --project-root <项目根> --date %s --product %s"
               % (date, product))
        return envelope_err(
            "missing_log",
            "推送被交付状态机拒绝：%s 的 %s 没有落盘登记（状态未达 LOGGED）。"
            "铁律 8.6 要求「先写本地文件 → delivery.py log 登记 → push.py 推送」。"
            "请先确认产物已写入本地数据区（当日日志 / 档案 / 计划），再执行：%s，"
            "然后重新推送。本条消息未发送。" % (date, product, cmd),
            date=date, product=product,
        ), None

    state = inst.get("state")
    key = inst.get("key")

    if state == "DRAFT":
        return envelope_err(
            "not_logged",
            "推送被交付状态机拒绝：实例 %s 仍是 DRAFT（产物尚未写入本地数据区）。"
            "先把产物落本地文件并 `delivery.py log`，再推送。本条消息未发送。" % key,
            key=key, state=state,
        ), None

    if state == "CLOSED":
        if product in ONCE_PER_DAY:
            tail = ("本产物属「一天一件」，不得建新实例重发（`delivery.py log` 会以 "
                    "once_per_day_pushed 拒登）；要改内容只能用 `push.py --update --product %s "
                    "--date %s` 原地更新同一张卡片（铁律 8.2 第 4 条）。" % (product, date))
        else:
            tail = "确需再发一份属于新产物，请 `delivery.py log` 建新实例（序号自增）。"
        return envelope_err(
            "closed",
            "推送被交付状态机拒绝：实例 %s 已 CLOSED（交付归档），不再接受推送。%s"
            "本条消息未发送。" % (key, tail),
            key=key, state=state, cadence=PRODUCT_CADENCE.get(product),
        ), None

    if state == "PUSHED" and not update:
        if product in ONCE_PER_DAY:
            newtail = ("本产物属「一天一件」，`delivery.py log` 建新实例也会被节奏围栏拒登"
                       "（once_per_day_pushed），不要尝试绕过。")
        else:
            newtail = "确实是一件新产物才 `delivery.py log` 建新实例。"
        return envelope_err(
            "duplicate",
            "推送被交付状态机拒绝：%s 的 %s 已在 %s 推送过（message_id=%s），不得重复推送。"
            "内容有错要改用 `push.py --update --product %s --date %s`，"
            "它会用同一个 message_id 原地更新那张卡片，不产生第二条消息；%s"
            "本条消息未发送（铁律 8.6）。"
            % (date, product, inst.get("pushed_at"), inst.get("message_id"), product, date, newtail),
            key=key, state=state, cadence=PRODUCT_CADENCE.get(product),
            message_id=inst.get("message_id"), pushed_at=inst.get("pushed_at"),
        ), None

    if update:
        if not inst.get("message_id"):
            return envelope_err(
                "update_unavailable",
                "无法原地更新：实例 %s 没有记录 message_id（推送时未取到消息 ID）。"
                "只能新建实例重发，或先用 `delivery.py list` 核对状态。本条消息未发送。" % key,
                key=key,
            ), None
        if inst.get("msg_type") and inst.get("msg_type") != "interactive":
            return envelope_err(
                "update_unsupported",
                "无法原地更新：实例 %s 的消息类型是 %s，飞书的消息更新接口只支持 interactive 卡片"
                "（PATCH /open-apis/im/v1/messages/:message_id）。文本/图片消息只能新建实例重发。"
                "本条消息未发送。" % (key, inst.get("msg_type")),
                key=key, msg_type=inst.get("msg_type"),
            ), None

    return envelope_ok("状态检查通过", key=key, state=state,
                       message_id=inst.get("message_id"), instance=inst), inst


def mark_pushed(project_root, key, message_id, chat_id=None, msg_type=None, detail=""):
    st = load_state(project_root)
    inst = st["instances"].get(key)
    if inst is None:
        return envelope_err("no_instance", "找不到实例 %s，无法置 PUSHED。" % key, key=key)
    inst["state"] = "PUSHED"
    inst["message_id"] = message_id
    inst["pushed_at"] = now_iso()
    if chat_id:
        inst["chat_id"] = chat_id
    if msg_type:
        inst["msg_type"] = msg_type
    touch(inst, "push", detail=detail or "push.py 推送成功，回写 message_id")
    save_state(project_root, st)
    return envelope_ok("已置 PUSHED 并回写 message_id", key=key, message_id=message_id,
                       state="PUSHED")


def mark_updated(project_root, key, detail=""):
    st = load_state(project_root)
    inst = st["instances"].get(key)
    if inst is None:
        return envelope_err("no_instance", "找不到实例 %s，无法记录更新。" % key, key=key)
    inst["updates"] = int(inst.get("updates") or 0) + 1
    inst["last_update_at"] = now_iso()
    touch(inst, "update", detail=detail or "push.py --update 原地更新同一张卡片")
    save_state(project_root, st)
    return envelope_ok("已记录一次原地更新", key=key, updates=inst["updates"],
                       message_id=inst.get("message_id"), state=inst.get("state"))


# ------------------------------------------------------------------ CLI 子命令

def cmd_log(a):
    perr = check_product(a.product)
    if perr:
        emit(perr)
    date = a.date or today()
    st = load_state(a.project_root)
    if not a.new:
        exist = find_pending(st, date, a.product)
        if exist:
            touch(exist, "log_reuse", detail=a.note or "复用未推送实例（重试不撑大序号）")
            save_state(a.project_root, st)
            emit(envelope_ok(
                "已复用未推送实例（状态 %s）" % exist.get("state"),
                key=exist["key"], date=date, product=a.product,
                seq=exist.get("seq"), state=exist.get("state"), reused=True,
            ))
    perr = check_once_per_day(st, date, a.product)
    if perr:
        emit(perr)
    seq = next_seq(st, date, a.product)
    key = make_key(date, a.product, seq)
    inst = {
        "key": key, "date": date, "product": a.product, "seq": seq,
        "state": "LOGGED", "note": a.note or "", "message_id": None,
        "chat_id": None, "msg_type": None, "logged_at": now_iso(),
        "pushed_at": None, "closed_at": None, "updates": 0, "history": [],
    }
    touch(inst, "log", state="LOGGED", detail=a.note or "产物已写入本地数据区")
    st["instances"][key] = inst
    save_state(a.project_root, st)
    emit(envelope_ok(
        "已登记落盘（LOGGED），可以推送",
        key=key, date=date, product=a.product, seq=seq, state="LOGGED",
        next_step="python .trae/skills/feishu-push/resources/push.py --project-root <项目根> "
                  "--msg-type <形态> --content-file <临时json> --product %s --date %s"
                  % (a.product, date),
    ))


def cmd_query(a):
    date = a.date or today()
    perr = check_product(a.product)
    if perr:
        emit(perr)
    st = load_state(a.project_root)
    items = instances_of(st, date, a.product)
    # 「已发出」= 实际推送过：PUSHED，或已归档 CLOSED（CLOSED 表示这条交付完成并归档，不是「没交付」）。
    # 若只按 state == "PUSHED" 过滤，归档后 query 会报 pushed=false，定时任务据此重发第二条消息——
    # 与铁律 8.2 第 4 条「单条产物消息原则」直接冲突，故 CLOSED 必须计入。
    delivered = [v for v in items
                 if v.get("pushed_at") or v.get("state") in ("PUSHED", "CLOSED")]
    archived = [v for v in delivered if v.get("state") == "CLOSED"]
    latest = delivered[-1] if delivered else (items[-1] if items else None)
    if not delivered:
        msg = "未推送"
    elif len(archived) == len(delivered):
        msg = "已推送并归档"
    else:
        msg = "已推送"
    emit(envelope_ok(
        msg,
        date=date, product=a.product,
        pushed=bool(delivered),           # ← 定时任务的幂等判据就看这个布尔
        pushed_count=len(delivered),
        archived_count=len(archived),
        instance_count=len(items),
        latest_message_id=(latest or {}).get("message_id"),
        latest_state=(latest or {}).get("state"),
        latest_pushed_at=(latest or {}).get("pushed_at"),
        instances=[{k: v.get(k) for k in
                    ("key", "seq", "state", "message_id", "logged_at", "pushed_at", "updates")}
                   for v in items],
    ))


def cmd_pending(a):
    st = load_state(a.project_root)
    items = [v for v in instances_of(st, a.date) if v.get("state") in ("LOGGED", "DRAFT")]
    emit(envelope_ok("待推送实例 %d 个" % len(items), count=len(items),
                     instances=[{k: v.get(k) for k in
                                 ("key", "date", "product", "seq", "state", "logged_at", "note")}
                                for v in items]))


def cmd_list(a):
    st = load_state(a.project_root)
    items = instances_of(st, a.date, a.product)
    emit(envelope_ok("实例 %d 个" % len(items), count=len(items), instances=items))


def cmd_mark_pushed(a):
    emit(mark_pushed(a.project_root, a.key, a.message_id, a.chat_id, a.msg_type, a.note or ""))


def cmd_mark_updated(a):
    emit(mark_updated(a.project_root, a.key, a.note or ""))


def cmd_close(a):
    st = load_state(a.project_root)
    inst = st["instances"].get(a.key)
    if inst is None:
        emit(envelope_err("no_instance", "找不到实例 %s。" % a.key, key=a.key))
    inst["state"] = "CLOSED"
    inst["closed_at"] = now_iso()
    touch(inst, "close", detail=a.note or "交付归档")
    save_state(a.project_root, st)
    emit(envelope_ok("已置 CLOSED", key=a.key, state="CLOSED"))


def cmd_products(a):
    emit(envelope_ok("产物类型白名单 %d 项" % len(PRODUCTS),
                     products=PRODUCTS, blocked=BLOCKED_PRODUCTS, states=list(STATES),
                     cadence=PRODUCT_CADENCE,
                     once_per_day=sorted(ONCE_PER_DAY), multi_per_day=sorted(MULTI_PER_DAY)))


def main():
    ap = argparse.ArgumentParser(description="交付状态机（铁律 8.6）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--project-root", required=True)
        p.add_argument("--date", help="YYYY-MM-DD，默认今天")
        p.add_argument("--product", help="产物类型，见 products 子命令")

    p = sub.add_parser("log", help="登记落盘（置 LOGGED）")
    common(p)
    p.add_argument("--note", help="落盘位置说明，如 daily/2026-09-07.md 晚间汇报章节")
    p.add_argument("--new", action="store_true",
                   help="强制建新实例（默认复用同日同产物未推送的实例）")
    p.set_defaults(func=cmd_log)

    p = sub.add_parser("query", help="幂等判据：今天这件产物推过没有")
    common(p)
    p.set_defaults(func=cmd_query)

    p = sub.add_parser("pending", help="列出已落盘未推送的实例")
    common(p)
    p.set_defaults(func=cmd_pending)

    p = sub.add_parser("list", help="列出实例")
    common(p)
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("mark-pushed", help="置 PUSHED 并回写 message_id（push.py 内部调用）")
    p.add_argument("--project-root", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--message-id", required=True)
    p.add_argument("--chat-id")
    p.add_argument("--msg-type")
    p.add_argument("--note")
    p.set_defaults(func=cmd_mark_pushed)

    p = sub.add_parser("mark-updated", help="记录一次原地更新（push.py --update 内部调用）")
    p.add_argument("--project-root", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--note")
    p.set_defaults(func=cmd_mark_updated)

    p = sub.add_parser("close", help="置 CLOSED")
    p.add_argument("--project-root", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--note")
    p.set_defaults(func=cmd_close)

    p = sub.add_parser("products", help="打印产物类型白名单")
    p.add_argument("--project-root", required=True)
    p.set_defaults(func=cmd_products)

    a = ap.parse_args()
    a.func(a)


if __name__ == "__main__":
    main()
