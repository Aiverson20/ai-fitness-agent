---
name: channel-setup
description: MANDATORY 飞书通道打通入口（安装器状态机驱动）。新机器首次接触、通道未打通、用户说「打通通道」「绑定办公助理」「启用飞书」、或任何推送被出口围栏拒绝（gate 错误）时，必须立即调用本技能，禁止任何手工步骤。
---

# channel-setup（飞书通道打通 · 安装器状态机入口）

打通飞书通道的**唯一入口**。本技能只干三件事：**运行安装器、读信封、对用户说话**。全部步骤由 `installer/install.py` 状态机硬编码驱动（办公助理主线，唯一路线），模型不得自行编排任何手工步骤。

## 核心原则

1. **确定性优先**：凡是不允许模型选择的事，代码里已经做死。模型的本分是逐步调用安装器、如实转述信封，不是发明流程。
2. **失败即停**：信封 `ok==false` 时原样呈现失败信息即停。有 `user_action` 字段→把该指引原样转述给用户，等用户完成后重跑 `next`；没有 `user_action`→呈现错误信封即停，不重试、不换路线、不猜测原因。
3. **办公助理是唯一路线**：安装器只实现办公助理主线（自建应用兜底路线已废除）。用户无办公助理时，转述唯一指引：请在 TraeWork 客户端启用「办公助理」并绑定飞书账号，然后重跑 `next`；不存在任何绕过安装器的替代路线。

## 命令表

全部命令在项目根目录下执行（`--project-root` 传项目根绝对路径）：

| 命令 | 作用 |
|---|---|
| `python installer/install.py status --project-root <项目根>` | 查看进度与下一步指引（任何时候都可以先跑这个） |
| `python installer/install.py next --project-root <项目根>` | 推进一态：断言/动作成功自动写状态；失败输出信封退出码 1 |
| `python installer/install.py complete --project-root <项目根> --state S6_ACCEPTANCE --confirmed` | 仅当用户确认飞书端验收通过后执行，收尾置 DONE |
| `python installer/install.py reset --project-root <项目根> --yes` | 清空状态重头再来（用户明确要求时才用） |

S3 主路线为确定性定位（直接向用户 open_id 发定位消息取回 chat_id），无需用户出手；仅当桥接凭证缺 `userOpenId` 降级为列表定位时，才可能请用户手动发消息或用 `--pick <chat_id>` 重跑 `next`。

## 六状态（由安装器强制执行，模型不得跳态乱序）

1. **S1_BRIDGE_CHECK**：断言办公助理已启用并绑定飞书（桥接凭证可读）。失败时转述唯一指引：请在 TraeWork 客户端启用「办公助理」并绑定飞书账号。
2. **S2_INJECT_CREDENTIALS**：凭证注入 lark-cli（只读桥接凭证，密钥绝不回显）。
3. **S3_LOCATE_P2P**：定位与用户的单聊会话并写入 `channel.json`（保留 base 段）。主路线确定性定位：直接向用户 open_id 发定位消息、从响应取回 chat_id，不需要会话预先存在、不需要用户手动发消息；仅当桥接凭证缺 `userOpenId` 时降级为列表定位（0 个→请用户先给机器人发一条消息；多个→列名单请用户确认或 `--pick`）。
4. **S4_TEST_SEND**：bot 身份发送测试消息（安装器直调飞书 API 验证线路，不走 push.py——那是业务推送入口，有出口围栏）。
5. **S5_DEPLOY_BASE**：部署基地（调度技能占位符替换 + 全局技能同步 + skill-config 合并注册 + 记忆指针）。
6. **S6_ACCEPTANCE**：人工门。请用户在飞书单聊发一条健身相关消息（无需 @），确认办公助理自主调用 `fitness-team-dispatch`；可对暗号「铁军」验证人格加载。用户确认通过后执行 `complete`。

## 标准工作循环

```
status → （NOT_STARTED / IN_PROGRESS）→ next → 读信封：
  ok==true 且有 next_state → 继续 next
  ok==true 且有 user_action（S6）→ 转述指引，等用户回来确认 → complete
  ok==false 且有 user_action → 转述指引，等用户完成 → 重跑 next
  ok==false 无 user_action → 原样呈现错误信封，失败即停
→ DONE 后：按铁律第 7 条在飞书端做团队亮相、引导建档
```

## 禁令（硬约束）

- **禁止手拼 lark-cli 命令**执行任何打通步骤（config init、列会话、发测试消息全部由安装器执行）。
- **禁止调用 RequestAuthorization 或任何用户身份授权**：办公助理路线全程 bot 身份。
- **禁止主动建群**：群聊免 @ 需要应用级敏感权限 `im:message.group_msg`，办公助理应用归 TraeWork 官方，团队与用户均无法开通（已实测确认）。
- **禁止手改 `channel.json` / `install-state.json`**：这两个文件只由安装器写入。
- **禁止跳态、乱序、绕过状态机**：推进只能靠 `next`，收尾只能靠 `complete`。
- **禁止用 `push.py` 发测试消息**：状态机未 DONE 时推送例程会被出口围栏拒发，这是设计使然；S4 测试消息由安装器直调 API 完成。

## 与出口围栏的关系

`feishu-push` 技能的 `push.py` / `base_sync.py` 在运行前会读取 `fitness-team/install-state.json`，状态机未 DONE 一律拒发（错误类型 `gate`）。遇到 `gate` 错误不要改数据、不要重试推送——回到本技能把通道打通是唯一出路。
