# -*- coding: utf-8 -*-
"""feishu-push 标准发送例程（铁律第 9 条 argv 模式）。

用法：
  # 标准三步（铁律 8.6）：先落本地文件 → delivery.py log 登记 → push.py 推送
  python push.py --project-root <项目根> --msg-type interactive --content-file card.json \
      --product daily_report --date 2026-09-07
  # 修正已发出的卡片：原地更新同一条消息，不产生第二条
  python push.py --project-root <项目根> --msg-type interactive --content-file card.json \
      --product daily_report --date 2026-09-07 --update

--chat-id 省略时读取 <项目根>/fitness-team/channel.json 的 target_chat_id。
--date 省略时取今天；--seq 省略时自动挑当日当产物待推送的实例。

**交付形态围栏（铁律 8.2，代码级物理拒发）**：
  1. 消息类型白名单只有 text / image / interactive 三种，白名单外（file、post、media 等）
     一律拒发，返回 error.type="policy"，message 里写明拒发原因与应改用的形态；
  2. 消息正文不得出现 computer:// 、file:/// 或本地绝对路径（形如 D:\\...），命中即拒发，
     同样返回 policy 信封。
  调用方收到 policy 信封时必须改换形态重发，不得改走其他通道绕过（措辞禁令已实证三次失效，
  故此围栏是唯一有强制力的一道）。

**交付状态机围栏（铁律 8.6，代码级物理拒发）**：通道围栏之后串 `installer/delivery.py`
  的 `resolve_for_push()`，返回 error.type="state" 信封的四种情形——
  1. missing_product / product_not_allowed / product_unknown：产物类型不在铁律 8.1 白名单
     （训练打卡分数被物理拦在这里，永不进飞书）；
  2. missing_log：产物未落盘登记，先 `delivery.py log` 再推；
  3. duplicate：当日当产物已 PUSHED，改用 --update 原地更新，不新发消息；
  4. closed / nothing_to_update / update_unsupported：实例状态或消息类型不支持该操作。
  推送成功后例程自动回写 message_id 与状态（mark_pushed / mark_updated），
  **不依赖调用方自觉**——这也是定时任务幂等判据机器化的数据来源（铁律 12）。

  原地更新走飞书官方接口 `PATCH /open-apis/im/v1/messages/:message_id`（lark-cli 无该
  typed 命令，走 `api` 逃生舱）；接口要求卡片 config 显式声明 update_multi=true，
  故本例程对 interactive 消息在发送前自动注入该字段，不依赖卡片生成方记得写。

**发送审计（M5）**：每次成功发送/更新都追加一行到 `fitness-team/logs/send-audit.jsonl`
  （时间 / action / 产物类型 / msg_type / message_id / chat_id / 实例 key）。
  配套对账脚本 `installer/send_audit.py reconcile` 拉取会话真实消息与该文件比对：
  审计里没有的机器人消息即「未经例程」，按形态分级报警（非白名单形态 / 规范卡片直发 = alert，
  疑似复述产物内容的对话回复 = review，极短过程性确认 = info）。
  审计写盘失败不阻断发送（消息已出去），但信封会标 `audit_written=false`，需人工补记。

bot 身份时取 App Secret 注入子进程（同时注入 LARKSUITE_CLI_STRICT_MODE=off），
绝不回显密钥（铁律 9.4）。**凭证唯一来源**：TraeWork 办公助理桥接凭证文件
（feishu-bridge/*/channel_config.json，只读）；办公助理主线是唯一路线，自建应用兜底路线
已废除，故 2026-09-05 起彻底移除「环境变量 → 注册表」取值分支——
已实证残留旧 secret 会截胡取值链导致 app secret invalid（code=10014），
且注册表删除只对新进程生效。取不到桥接凭证即视为通道未打通，
由调用方按铁律 9.5 回到 channel-setup 安装器，不存在任何旁路。
"""
import argparse
import glob
import json
import os
import shutil
import subprocess
import sys
import tempfile


def find_cli():
    """定位 lark-cli：先走 PATH（宿主注入），失败再扫描飞书插件安装目录兜底。"""
    exe = shutil.which("lark-cli")
    if exe:
        return exe
    home = os.path.expanduser("~")
    patterns = [
        os.path.join(home, ".trae-cn", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
        os.path.join(home, ".trae", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
    ]
    candidates = []
    for pat in patterns:
        candidates.extend(glob.glob(pat))
    if candidates:
        # 多个版本取目录名最新（版本号为语义化排序，字典序在此场景足够）
        return sorted(candidates)[-1]
    return None


def find_bridge_workspace():
    """定位 TraeWork 办公助理桥接凭证文件的 feishu workspace 段（只读，铁律 9.4）。

    返回含 appId / appSecret 的 dict；找不到或不可读时返回 None。绝不回显其中内容。
    """
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    patterns = [
        os.path.join(appdata, "TRAE*", "User", "globalStorage",
                     "cloudide.icube-im-bridge", "feishu-bridge", "*", "channel_config.json"),
    ]
    candidates = []
    for pat in patterns:
        candidates.extend(glob.glob(pat))
    for p in sorted(candidates):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            continue
        ws = ((data.get("channels") or {}).get("feishu") or {}).get("workspace") or {}
        if ws.get("appSecret"):
            return ws
    return None


def get_secret(channel_app_id=None):
    """取 App Secret（铁律 9.4）：桥接凭证文件是唯一来源，不存在任何兜底分支。

    已实证：环境变量/注册表残留的旧 secret 截胡取值链会导致 app secret invalid（code=10014），
    且注册表删除只对新进程生效，已运行的宿主/终端进程环境块里残留仍在。
    自建应用兜底路线废除后这两处分支已无合法用途，2026-09-05 彻底移除（含 winreg 读取）。
    channel_app_id 与桥接 appId 不一致时同样返回 None：绝不跨应用取密钥，
    由调用方按 credentials 信封回到 channel-setup 重新打通（安装器会重写 channel.json）。
    """
    ws = find_bridge_workspace()
    if not ws:
        return None
    if channel_app_id and channel_app_id != ws.get("appId"):
        return None
    return ws.get("appSecret") or None


def fail(envelope):
    print(json.dumps(envelope, ensure_ascii=False))
    sys.exit(1)


# ---------------------------------------------------------------------------
# 交付形态围栏（铁律 8.2）：飞书端只发人类可读消息。
# 措辞级禁令已实证三次失效，故在此做代码级物理拒发，并把拒发原因与替代形态
# 回传调用方（模型），让其当场改道而不是静默丢弃。
# ---------------------------------------------------------------------------
ALLOWED_MSG_TYPES = ("text", "image", "interactive")

ALLOWED_MSG_TYPE_DESC = {
    "text": "纯文本消息（简短通知、降级兜底）",
    "image": "图片消息（餐食照/训练照/体型照等图片类产物）",
    "interactive": "Card 2.0 交互卡片（档案卡、计划卡、晚间汇报卡、复盘报告等一切结构化产物）",
}

MSG_TYPE_POLICY_HINTS = {
    "file": "禁止把本地数据文件（json / md / html / xlsx 等原件）发给用户：数据文件是内部实现细节，"
            "飞书端只发人类可读消息。结构化产物请改用 interactive（Card 2.0 卡片），"
            "纯文字请改用 text，图片请改用 image。",
    "media": "音视频文件不在团队交付形态内。图片类产物改用 image，结构化产物改用 interactive。",
    "audio": "语音消息不在团队交付形态内。请改用 text 或 interactive。",
    "post": "富文本 post 不在团队交付形态内（移动端排版不可控）。结构化内容一律改用 interactive 卡片，"
            "卡片内可用表格、分栏等原生元素呈现。",
    "sticker": "表情消息不承载业务产物。请改用 text 或 interactive。",
}

# 飞书消息正文禁止出现本地路径 / 电脑端链接：产物路径只属于桌面端对话与本地数据区，
# 发到手机端只会变成点不开的垃圾信息（2026-09-05 三张答复卡都贴了「本地存档」链接）。
LOCAL_REF_RULES = (
    ("computer://", "computer:// 桌面端文件链接"),
    ("file:///", "file:/// 本地文件协议链接"),
    ("drive-letter-path", "本地绝对路径（形如 D:\\\\... 或 C:/...）"),
)

_DRIVE_PATH_RE = None


def _drive_path_regex():
    global _DRIVE_PATH_RE
    if _DRIVE_PATH_RE is None:
        import re

        # 单字母盘符 + 冒号 + 斜杠，前面不能是字母数字（避免误伤 https:// 等 URL）
        _DRIVE_PATH_RE = re.compile(r"(?<![A-Za-z0-9_])[A-Za-z]:[\\/][^\s\"'<>|]{1,}")
    return _DRIVE_PATH_RE


def _find_local_ref(content):
    """返回正文中命中的第一处本地引用描述；干净时返回 None。"""
    low = content.lower()
    for token, desc in LOCAL_REF_RULES:
        if token == "drive-letter-path":
            m = _drive_path_regex().search(content)
            if m:
                return desc, m.group(0)[:120]
        elif token in low:
            i = low.index(token)
            return desc, content[max(0, i - 20):i + 100]
    return None


def check_msg_type_fence(msg_type):
    """交付形态围栏之一：消息类型白名单。白名单外一律拒发（error.type=policy）。"""
    if msg_type in ALLOWED_MSG_TYPES:
        return
    allowed = "、".join("%s（%s）" % (k, ALLOWED_MSG_TYPE_DESC[k]) for k in ALLOWED_MSG_TYPES)
    hint = MSG_TYPE_POLICY_HINTS.get(
        msg_type,
        "该消息类型不在团队交付白名单内。结构化产物请改用 interactive（Card 2.0 卡片），"
        "纯文字请改用 text，图片请改用 image。",
    )
    fail({
        "ok": False,
        "error": {
            "type": "policy",
            "code": "msg_type_not_allowed",
            "rejected_msg_type": msg_type,
            "allowed_msg_types": list(ALLOWED_MSG_TYPES),
            "message": "推送被交付形态围栏拒绝：msg_type=%s 不在白名单内。%s 允许的形态：%s。"
                       "本条消息未发送，请改换形态后重新调用（铁律 8.2）。"
                       % (msg_type, hint, allowed),
        },
    })


def check_content_fence(content):
    """交付形态围栏之二：正文不得出现本地路径 / 桌面端链接（error.type=policy）。"""
    hit = _find_local_ref(content)
    if not hit:
        return
    desc, snippet = hit
    fail({
        "ok": False,
        "error": {
            "type": "policy",
            "code": "local_path_in_content",
            "matched": desc,
            "snippet": snippet,
            "message": "推送被交付形态围栏拒绝：消息正文包含%s。飞书端只发人类可读内容，"
                       "产物路径与桌面端链接属于内部实现细节，用户在手机上点不开。"
                       "请去掉路径/链接后重发；确需告知本地存档位置时，只在桌面端对话里说"
                       "（铁律 8.2）。本条消息未发送。" % desc,
        },
    })


def check_install_gate(project_root):
    """出口围栏：通道状态机未 DONE 一律拒发（代码约束优先于任何文字指令）。"""
    gate_path = os.path.join(project_root, "fitness-team", "install-state.json")
    try:
        with open(gate_path, encoding="utf-8") as f:
            st = json.load(f)
        status = ((st.get("scenarios") or {}).get("feishu_channel") or {}).get("status")
    except (OSError, json.JSONDecodeError):
        status = None
    if status != "DONE":
        fail({
            "ok": False,
            "error": {
                "type": "gate",
                "message": "飞书通道未打通（安装器状态机未 DONE），推送被拒绝。"
                           "请先调用 channel-setup 技能运行安装器："
                           "python installer/install.py next --project-root <项目根>",
            },
        })


# ---------------------------------------------------------------------------
# 交付状态机（铁律 8.6）：未落盘不推、推过不重推、修正只改同一张卡。
# 状态逻辑的唯一实现在 installer/delivery.py，本例程只调用不复制，避免双轨。
# 取不到 delivery.py 一律 fail-closed（拒发）：状态机是硬门槛，不是可选装饰。
# ---------------------------------------------------------------------------

def load_delivery(project_root):
    """动态加载项目根的 installer/delivery.py（桌面端与飞书端都靠 --project-root 定位）。"""
    inst_dir = os.path.join(project_root, "installer")
    if inst_dir not in sys.path:
        sys.path.insert(0, inst_dir)
    try:
        import delivery  # noqa: PLC0415
        return delivery
    except ImportError:
        return None


def check_delivery_state(project_root, product, date, seq, update):
    """状态机围栏。返回 (envelope_or_None, instance_or_None, delivery_module)。"""
    dv = load_delivery(project_root)
    if dv is None:
        return {
            "ok": False,
            "error": {
                "type": "environment",
                "code": "delivery_missing",
                "message": "找不到交付状态机例程 installer/delivery.py（项目根：%s）。"
                           "状态机是推送的硬门槛，缺失即拒发（fail-closed，铁律 8.6）。"
                           "请核对 --project-root 是否指向项目根；分发包缺件时重新部署。"
                           "本条消息未发送。" % project_root,
            },
        }, None, None
    env, inst = dv.resolve_for_push(project_root, product=product, date=date,
                                    seq=seq, update=update)
    if not env.get("ok"):
        return env, None, dv
    return None, inst, dv


def ensure_update_multi(content, msg_type):
    """interactive 卡片发送前注入 config.update_multi=true。

    飞书的消息更新接口（PATCH /open-apis/im/v1/messages/:message_id）要求更新前后卡片的
    config 均显式声明 update_multi=true，否则 M7 的「原地改同一张卡」在 14 天内也改不动。
    在例程里统一注入，不依赖每个卡片生成方记得写。注入失败原样返回，不阻断发送。
    """
    if msg_type != "interactive":
        return content
    try:
        card = json.loads(content)
    except json.JSONDecodeError:
        return content
    if not isinstance(card, dict):
        return content
    cfg = card.get("config")
    if not isinstance(cfg, dict):
        cfg = {}
    if cfg.get("update_multi") is True:
        return content
    cfg["update_multi"] = True
    card["config"] = cfg
    return json.dumps(card, ensure_ascii=False)


def extract_message_id(obj):
    """从 lark-cli 返回里递归找 message_id（不同版本可能在顶层或 data 段）。"""
    if isinstance(obj, dict):
        mid = obj.get("message_id")
        if isinstance(mid, str) and mid:
            return mid
        for v in obj.values():
            got = extract_message_id(v)
            if got:
                return got
    elif isinstance(obj, list):
        for v in obj:
            got = extract_message_id(v)
            if got:
                return got
    return None


def cli_succeeded(stdout):
    """判定 lark-cli 调用成败：信封 ok 为真，或裸 API 响应 code==0（api 逃生舱）。"""
    try:
        data = json.loads(stdout)
    except (json.JSONDecodeError, TypeError):
        return False, None
    if not isinstance(data, dict):
        return False, data
    if data.get("ok") is True:
        return True, data
    if data.get("ok") is False:
        return False, data
    if data.get("code") == 0:
        return True, data
    return False, data


# ---------------------------------------------------------------------------
# 发送审计（M5）：每次成功发送/更新追加一行到 fitness-team/logs/send-audit.jsonl。
# 用途是让「绕过例程直调 lark-cli」可被事后发现——对账脚本 installer/send_audit.py
# 拉取会话真实消息与本文件比对，未经例程的消息即报警（2026-09-07 的 file 原件与
# 自动卡片化打分卡都属此型）。审计只是记录层：**写失败不阻断已完成的发送**，
# 但会在返回信封里如实标出 audit_written=false 与原因，由调用方补记。
# ---------------------------------------------------------------------------

AUDIT_RELPATH = os.path.join("fitness-team", "logs", "send-audit.jsonl")


def append_audit(project_root, record):
    """追加一行审计（JSON Lines）。返回 (written_bool, error_or_None)。"""
    path = os.path.join(project_root, AUDIT_RELPATH)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
        return True, None
    except (OSError, TypeError, ValueError) as e:
        return False, "%s: %s" % (type(e).__name__, e)


def audit_record(action, product, inst, inst_date, msg_type, message_id, chat_id, identity,
                 updates=None):
    """组装审计行。字段口径与对账脚本一致，勿随意增删（新增字段须同步 send_audit.py）。"""
    from datetime import datetime

    rec = {
        "time": datetime.now().isoformat(timespec="seconds"),
        "action": action,                      # send（新消息） / update（原地改同一张卡）
        "product": product,
        "date": inst_date,
        "key": (inst or {}).get("key"),
        "seq": (inst or {}).get("seq"),
        "msg_type": msg_type,
        "message_id": message_id,
        "chat_id": chat_id,
        "identity": identity,
        "routed": True,                        # 经例程发出——对账时以此区分合规消息
    }
    if updates is not None:
        rec["updates"] = updates
    return rec


def fetch_tenant_token(app_id, secret, brand):
    """用 App ID + Secret 现换 tenant_access_token（token 约 2 小时过期，不落盘）。"""
    import urllib.request

    host = "https://open.larksuite.com" if brand == "lark" else "https://open.feishu.cn"
    body = json.dumps({"app_id": app_id, "app_secret": secret}).encode("utf-8")
    req = urllib.request.Request(
        host + "/open-apis/auth/v3/tenant_access_token/internal",
        data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if data.get("code") != 0:
        raise RuntimeError(f"token 换取失败: code={data.get('code')} msg={data.get('msg')}")
    return data["tenant_access_token"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", required=True)
    ap.add_argument("--chat-id")
    ap.add_argument("--msg-type", default="text")
    ap.add_argument("--content-json")
    ap.add_argument("--content-file")
    ap.add_argument("--as", dest="identity", default="bot", choices=["bot", "user"])
    # 交付状态机（铁律 8.6）
    ap.add_argument("--product", help="产物类型（铁律 8.1 白名单，见 delivery.py products）")
    ap.add_argument("--date", help="产物日期 YYYY-MM-DD，默认今天")
    ap.add_argument("--seq", help="实例序号，默认自动挑当日当产物待推送的实例")
    ap.add_argument("--update", action="store_true",
                    help="原地更新已发出的卡片（同一条消息，不新发），仅 interactive 可用")
    a = ap.parse_args()

    # 0. 交付形态围栏：消息类型白名单，白名单外物理拒发并回传原因（铁律 8.2）
    check_msg_type_fence(a.msg_type)

    # 0.5 出口围栏：状态机未 DONE 拒发（铁律 9.5 指针化后的物理约束）
    check_install_gate(a.project_root)

    # 0.6 交付状态机围栏：产物白名单 + 未落盘不推 + 推过不重推（铁律 8.6 / 8.1）
    st_env, inst, dv = check_delivery_state(a.project_root, a.product, a.date, a.seq, a.update)
    if st_env:
        fail(st_env)
    inst_date = inst.get("date")

    # 1. 目标会话与通道配置
    channel = {}
    ch_path = os.path.join(a.project_root, "fitness-team", "channel.json")
    try:
        with open(ch_path, encoding="utf-8") as f:
            channel = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        if not a.chat_id:
            fail({"ok": False, "error": {"type": "config", "message": f"读取 channel.json 失败: {e}"}})
    chat_id = a.chat_id or channel.get("target_chat_id")
    if not chat_id and not a.update:
        fail({"ok": False, "error": {"type": "config", "message": "缺少目标会话：请传 --chat-id 或在 channel.json 填写 target_chat_id"}})

    # 2. 负载
    if a.content_file:
        try:
            with open(a.content_file, encoding="utf-8") as f:
                content = f.read().strip()
        except OSError as e:
            fail({"ok": False, "error": {"type": "io", "message": str(e)}})
    else:
        content = a.content_json or ""
    try:
        json.loads(content)
    except json.JSONDecodeError as e:
        fail({"ok": False, "error": {"type": "validation", "message": f"content 不是合法 JSON: {e}"}})

    # 2.5 交付形态围栏：正文不得含本地路径 / 桌面端链接（铁律 8.2）
    check_content_fence(content)

    # 2.6 卡片可更新性：注入 config.update_multi=true（M7 原地更新的前提，飞书接口硬要求）
    content = ensure_update_multi(content, a.msg_type)

    # 3. lark-cli 定位（PATH 优先，插件目录兜底）
    exe = find_cli()
    if not exe:
        fail({"ok": False, "error": {"type": "environment", "message": "找不到 lark-cli：PATH 与飞书插件目录均无该可执行文件"}})

    # 4. 子进程环境（密钥只在此注入，不回显）
    env = dict(os.environ)
    if a.identity == "bot":
        env["LARKSUITE_CLI_STRICT_MODE"] = "off"
        # 移除宿主注入的 user token，避免压过覆写后的 bot 身份（新宿主凭证外部托管模式）
        env.pop("LARKSUITE_CLI_USER_ACCESS_TOKEN", None)
        # 先解析 app_id 再取密钥：桥接凭证是唯一来源，app_id 不一致即视为配置漂移，不跨应用取密钥
        app_id = channel.get("app_id") or os.environ.get("LARKSUITE_CLI_APP_ID")
        if not app_id:
            ws = find_bridge_workspace()
            if ws:
                app_id = ws.get("appId")
        if not app_id:
            fail({"ok": False, "error": {"type": "credentials", "message": "缺少 app_id：请在 channel.json 填写 app_id，或先启用办公助理并绑定飞书"}})
        secret = get_secret(app_id)
        if not secret:
            fail({
                "ok": False,
                "error": {
                    "type": "credentials",
                    "code": "app_secret_unavailable",
                    "message": "未找到 App Secret：办公助理桥接凭证文件不可读，或 channel.json 的 app_id 与桥接应用不一致（配置漂移）。"
                               "凭证唯一来源是办公助理桥接凭证文件——自建应用兜底路线已废除，"
                               "不存在环境变量/注册表旁路，也不要手工拼密钥。"
                               "请调用 channel-setup 技能重跑安装器（铁律 9.5）："
                               "python installer/install.py next --project-root <项目根>；"
                               "安装器 S2/S3 会重新注入凭证并重写 channel.json。",
                },
            })
        env["LARKSUITE_CLI_APP_ID"] = app_id  # 覆盖宿主默认注入，使用通道配置的应用
        env["LARKSUITE_CLI_APP_SECRET"] = secret
        # 宿主发行版不自行用 APP_ID+APP_SECRET 换 token，这里现换并直接注入（token 短期有效，不落盘）
        if not os.environ.get("LARKSUITE_CLI_TENANT_ACCESS_TOKEN"):
            try:
                brand = (channel.get("brand") or os.environ.get("LARKSUITE_CLI_BRAND") or "feishu").lower()
                env["LARKSUITE_CLI_TENANT_ACCESS_TOKEN"] = fetch_tenant_token(app_id, secret, brand)
            except Exception as e:  # noqa: BLE001
                fail({"ok": False, "error": {"type": "credentials", "message": str(e)}})

    # 5. argv 直调（铁律 9.2）
    #    --update 走飞书官方消息更新接口（lark-cli 无 typed 命令，用 api 逃生舱）：
    #    PATCH /open-apis/im/v1/messages/:message_id，body 只有 content（卡片 JSON 字符串）。
    #    更新身份须与发送身份一致、仅 14 天内、单条消息 5 QPS、卡片前后都要带 config.update_multi。
    #    坑（实证 2026-09-07）：lark-cli 的 --data @file 只接受**当前目录内的相对路径**，
    #    传系统临时目录的绝对路径会被 validation 拒收，故把 body 写进专用临时目录并以该目录为 cwd。
    patch_dir = None
    run_cwd = None
    if a.update:
        body = {"content": content}
        patch_dir = tempfile.mkdtemp(prefix="lark_patch_")
        with open(os.path.join(patch_dir, "patch.json"), "w", encoding="utf-8") as f:
            json.dump(body, f, ensure_ascii=False)
        run_cwd = patch_dir
        argv = [
            exe, "api", "PATCH",
            "/open-apis/im/v1/messages/%s" % inst.get("message_id"),
            "--as", a.identity,
            "--data", "@patch.json",
            "--json",
        ]
    else:
        argv = [
            exe, "im", "+messages-send",
            "--as", a.identity,
            "--chat-id", chat_id,
            "--msg-type", a.msg_type,
            "--content", content,
            "--json",
        ]
    if exe.lower().endswith((".cmd", ".bat")):
        argv = ["cmd", "/c"] + argv

    r = subprocess.run(argv, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       env=env, cwd=run_cwd)
    if patch_dir:
        shutil.rmtree(patch_dir, ignore_errors=True)
    print("RC:", r.returncode)
    print("STDOUT:", r.stdout)
    print("STDERR:", r.stderr)

    ok, data = cli_succeeded(r.stdout)

    # 6. 成功后由例程自动回写状态机（不依赖调用方自觉，铁律 8.6）+ 追加发送审计（M5）
    if ok:
        if a.update:
            wb = dv.mark_updated(a.project_root, inst["key"],
                                 detail="push.py --update 原地更新卡片内容")
            aw, aerr = append_audit(a.project_root, audit_record(
                "update", a.product, inst, inst_date, a.msg_type,
                inst.get("message_id"), chat_id, a.identity,
                updates=wb.get("updates")))
            print(json.dumps({
                "ok": True, "action": "update", "key": inst["key"],
                "product": a.product, "date": inst_date,
                "message_id": inst.get("message_id"),
                "updates": wb.get("updates"), "state": "PUSHED",
                "state_writeback": wb.get("ok", False),
                "audit_written": aw, "audit_error": aerr,
                "message": "已原地更新同一条消息（message_id=%s），未产生新消息（铁律 8.6）。"
                           % inst.get("message_id"),
            }, ensure_ascii=False))
        else:
            mid = extract_message_id(data)
            wb = dv.mark_pushed(a.project_root, inst["key"], mid, chat_id, a.msg_type,
                                detail="push.py 推送成功")
            aw, aerr = append_audit(a.project_root, audit_record(
                "send", a.product, inst, inst_date, a.msg_type,
                mid, chat_id, a.identity))
            print(json.dumps({
                "ok": True, "action": "send", "key": inst["key"],
                "product": a.product, "date": inst_date,
                "message_id": mid, "state": "PUSHED",
                "state_writeback": wb.get("ok", False),
                "audit_written": aw, "audit_error": aerr,
                "message": ("推送成功，状态机已置 PUSHED 并回写 message_id。"
                            if mid else
                            "推送成功并已置 PUSHED，但未从返回里取到 message_id："
                            "该实例后续无法 --update 原地更新，修正需新建实例。"),
            }, ensure_ascii=False))
        if not aw:
            # 审计写盘失败不影响发送结果（消息已出去），但必须让调用方知道对账会缺这一行。
            print(json.dumps({
                "ok": False, "warning": "audit_write_failed",
                "message": "发送已成功，但审计行写入 %s 失败：%s。"
                           "该消息在对账时会被判为「未经例程」，请人工补记（M5）。"
                           % (AUDIT_RELPATH, aerr),
            }, ensure_ascii=False))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
