# -*- coding: utf-8 -*-
"""feishu-push 数据同步例程（铁律第 9 条 argv 模式）。

把本地数据区的档案 / 餐食 / 分数数据写入「健身团队 · 数据中心」多维表格。
Base 位置读 <项目根>/fitness-team/channel.json 的 base 段。

用法：
  # 写记录（payload 为 {"create_records":[{字段名: 值, ...}]}）
  python base_sync.py write --project-root <根> --table 餐食表 --records-file payload.json

  # 追加附件（记录已存在后调用；--file 可重复）
  python base_sync.py attach --project-root <根> --table 餐食表 --record-id recXXX \
      --field 餐食照片 --file <图片路径> [--file <图片路径2>]

CellValue 约定（见 lark-base-cell-value 规范）：
  datetime 传 "YYYY-MM-DD HH:mm"；select 传选项名数组；number 传 JSON 数字。

**同步身份统一 bot（铁律 10.1，代码级围栏）**：`--as` 只接受 bot，传其他值一律拒绝并返回
  error.type="policy"（code=identity_not_allowed），信封里写明应改用 bot——
  用户身份回退分支属自建应用兜底路线遗物，2026-09-05 已移除。
**凭证唯一来源**：办公助理桥接凭证文件（只读）；环境变量/注册表分支已彻底移除，
  取不到即按 credentials 信封回到 channel-setup 重跑安装器（铁律 9.5），不存在旁路。
"""
import argparse
import glob
import json
import os
import shutil
import subprocess
import sys


def fail(envelope):
    print(json.dumps(envelope, ensure_ascii=False))
    sys.exit(1)


def check_install_gate(project_root):
    """出口围栏：通道状态机未 DONE 一律拒发（代码约束优先于任何文字指令）。"""
    gate_path = os.path.join(project_root, "fitness-team", "install-state.json")
    try:
        with open(gate_path, encoding="utf-8") as f:
            st = json.load(f)
        status = ((st.get("scenarios") or {}).get("feishu_channel") or {}).get("status")
    except (OSError, json.JSONDecodeError):
        status = None
    if status != "DONE":
        fail({
            "ok": False,
            "error": {
                "type": "gate",
                "message": "飞书通道未打通（安装器状态机未 DONE），同步被拒绝。"
                           "请先调用 channel-setup 技能运行安装器："
                           "python installer/install.py next --project-root <项目根>",
            },
        })


def load_channel(project_root):
    ch_path = os.path.join(project_root, "fitness-team", "channel.json")
    try:
        with open(ch_path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        fail({"ok": False, "error": {"type": "config", "message": f"读取 channel.json 失败: {e}"}})


def find_cli():
    """定位 lark-cli：先走 PATH（宿主注入），失败再扫描飞书插件安装目录兜底。"""
    exe = shutil.which("lark-cli")
    if exe:
        return exe
    home = os.path.expanduser("~")
    patterns = [
        os.path.join(home, ".trae-cn", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
        os.path.join(home, ".trae", "plugins", "trae-remote-official", "lark", "*", "bin", "lark-cli.exe"),
    ]
    candidates = []
    for pat in patterns:
        candidates.extend(glob.glob(pat))
    if candidates:
        return sorted(candidates)[-1]
    fail({"ok": False, "error": {"type": "environment", "message": "找不到 lark-cli：PATH 与飞书插件目录均无该可执行文件"}})


def find_bridge_workspace():
    """定位 TraeWork 办公助理桥接凭证文件的 feishu workspace 段（只读，铁律 9.4）。

    返回含 appId / appSecret 的 dict；找不到或不可读时返回 None。绝不回显其中内容。
    """
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    patterns = [
        os.path.join(appdata, "TRAE*", "User", "globalStorage",
                     "cloudide.icube-im-bridge", "feishu-bridge", "*", "channel_config.json"),
    ]
    candidates = []
    for pat in patterns:
        candidates.extend(glob.glob(pat))
    for p in sorted(candidates):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            continue
        ws = ((data.get("channels") or {}).get("feishu") or {}).get("workspace") or {}
        if ws.get("appSecret"):
            return ws
    return None


def get_secret(channel_app_id=None):
    """取 App Secret（铁律 9.4）：桥接凭证文件是唯一来源，不存在任何兜底分支。

    已实证：环境变量/注册表残留的旧 secret 截胡取值链会导致 app secret invalid（code=10014），
    且注册表删除只对新进程生效，已运行的宿主/终端进程环境块里残留仍在。
    自建应用兜底路线废除后这两处分支已无合法用途，2026-09-05 彻底移除（含 winreg 读取）。
    channel_app_id 与桥接 appId 不一致时同样返回 None：绝不跨应用取密钥，
    由调用方按 credentials 信封回到 channel-setup 重新打通（安装器会重写 channel.json）。
    """
    ws = find_bridge_workspace()
    if not ws:
        return None
    if channel_app_id and channel_app_id != ws.get("appId"):
        return None
    return ws.get("appSecret") or None


def fetch_tenant_token(app_id, secret, brand):
    """用 App ID + Secret 现换 tenant_access_token（token 约 2 小时过期，不落盘）。"""
    import urllib.request

    host = "https://open.larksuite.com" if brand == "lark" else "https://open.feishu.cn"
    body = json.dumps({"app_id": app_id, "app_secret": secret}).encode("utf-8")
    req = urllib.request.Request(
        host + "/open-apis/auth/v3/tenant_access_token/internal",
        data=body,
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if data.get("code") != 0:
        raise RuntimeError(f"token 换取失败: code={data.get('code')} msg={data.get('msg')}")
    return data["tenant_access_token"]


def check_identity_fence(identity):
    """同步身份围栏（铁律 10.1）：多维表格同步只走 bot 身份，非 bot 一律拒绝。

    用户身份回退分支是自建应用兜底路线的遗物，2026-09-05 移除；
    这里不用 argparse choices 拦（那样只会吐 usage 文本、退出码 2），
    而是回传 policy 信封，让调用方（模型）读到原因后当场改回 bot。
    """
    if identity == "bot":
        return
    fail({
        "ok": False,
        "error": {
            "type": "policy",
            "code": "identity_not_allowed",
            "rejected_identity": identity,
            "allowed_identity": "bot",
            "message": "多维表格同步被身份围栏拒绝：--as %s 不受支持（铁律 10.1 统一 bot 身份，"
                       "已实测 base 三档权限足够）。本次同步未执行，请去掉 --as 参数"
                       "（默认即 bot）后重新调用；若报缺权限，把错误信封里的 console_url 直链"
                       "交给用户开通，不得改用用户身份绕过。" % identity,
        },
    })


def build_env(channel, identity):
    """子进程环境：bot 身份注入桥接凭证（含新宿主凭证外部托管模式的覆写），密钥不回显（铁律 9.4）。"""
    check_identity_fence(identity)
    env = dict(os.environ)
    env["LARKSUITE_CLI_STRICT_MODE"] = "off"
    # 移除宿主注入的 user token，避免压过覆写后的 bot 身份（新宿主凭证外部托管模式）
    env.pop("LARKSUITE_CLI_USER_ACCESS_TOKEN", None)
    # 先解析 app_id 再取密钥：桥接凭证是唯一来源，app_id 不一致即视为配置漂移，不跨应用取密钥
    app_id = channel.get("app_id") or os.environ.get("LARKSUITE_CLI_APP_ID")
    if not app_id:
        ws = find_bridge_workspace()
        if ws:
            app_id = ws.get("appId")
    if not app_id:
        fail({"ok": False, "error": {"type": "credentials", "message": "缺少 app_id：请在 channel.json 填写 app_id，或先启用办公助理并绑定飞书"}})
    secret = get_secret(app_id)
    if not secret:
        fail({
            "ok": False,
            "error": {
                "type": "credentials",
                "code": "app_secret_unavailable",
                "message": "未找到 App Secret：办公助理桥接凭证文件不可读，或 channel.json 的 app_id 与桥接应用不一致（配置漂移）。"
                           "凭证唯一来源是办公助理桥接凭证文件——自建应用兜底路线已废除，"
                           "不存在环境变量/注册表旁路，也不要手工拼密钥。"
                           "请调用 channel-setup 技能重跑安装器（铁律 9.5）："
                           "python installer/install.py next --project-root <项目根>；"
                           "安装器 S2/S3 会重新注入凭证并重写 channel.json。",
            },
        })
    env["LARKSUITE_CLI_APP_ID"] = app_id  # 覆盖宿主默认注入，使用通道配置的应用
    env["LARKSUITE_CLI_APP_SECRET"] = secret
    # 宿主发行版不自行用 APP_ID+APP_SECRET 换 token，这里现换并直接注入（token 短期有效，不落盘）
    if not os.environ.get("LARKSUITE_CLI_TENANT_ACCESS_TOKEN"):
        try:
            brand = (channel.get("brand") or os.environ.get("LARKSUITE_CLI_BRAND") or "feishu").lower()
            env["LARKSUITE_CLI_TENANT_ACCESS_TOKEN"] = fetch_tenant_token(app_id, secret, brand)
        except Exception as e:  # noqa: BLE001
            fail({"ok": False, "error": {"type": "credentials", "message": str(e)}})
    return env


def run_cli(exe, argv_tail, identity, cwd=None, env=None):
    argv = [exe, "base"] + argv_tail + ["--as", identity, "--format", "json"]
    if exe.lower().endswith((".cmd", ".bat")):
        argv = ["cmd", "/c"] + argv
    r = subprocess.run(argv, capture_output=True, text=True, encoding="utf-8", errors="replace",
                       cwd=cwd, env=env)
    try:
        out = json.loads(r.stdout)
    except json.JSONDecodeError:
        out = None
    ok = False
    if isinstance(out, dict):
        ok = out.get("ok") is True
    if not ok:
        fail({
            "ok": False,
            "error": {
                "type": "cli",
                "returncode": r.returncode,
                "stdout": r.stdout[-2000:],
                "stderr": r.stderr[-2000:],
            },
        })
    return out


def cmd_write(a):
    channel = load_channel(a.project_root)
    base = channel.get("base") or {}
    base_token = base.get("base_token")
    table_id = (base.get("tables") or {}).get(a.table)
    if not base_token or not table_id:
        fail({"ok": False, "error": {"type": "config", "message": f"channel.json 缺少 base 配置或表「{a.table}」"}})

    try:
        with open(a.records_file, encoding="utf-8") as f:
            payload = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        fail({"ok": False, "error": {"type": "io", "message": f"读取记录文件失败: {e}"}})
    if "create_records" not in payload:
        fail({"ok": False, "error": {"type": "validation", "message": "记录文件必须包含 create_records 数组"}})

    exe = find_cli()
    env = build_env(channel, a.identity)
    # 负载以相对路径 @./<文件> 引用（CLI 只认相对路径）：把工作目录切到负载文件所在目录，
    # JSON 不进命令行（铁律 9.1 / 9.2）
    records_abs = os.path.abspath(a.records_file)
    payload_dir = os.path.dirname(records_abs)
    payload_name = os.path.basename(records_abs)
    out = run_cli(exe, [
        "+record-batch-create",
        "--base-token", base_token,
        "--table-id", table_id,
        "--json", "@./" + payload_name,
    ], a.identity, cwd=payload_dir, env=env)
    record_ids = (out.get("data") or {}).get("record_id_list") or []
    print(json.dumps({"ok": True, "record_ids": record_ids}, ensure_ascii=False))


def cmd_attach(a):
    channel = load_channel(a.project_root)
    base = channel.get("base") or {}
    base_token = base.get("base_token")
    table_id = (base.get("tables") or {}).get(a.table)
    if not base_token or not table_id:
        fail({"ok": False, "error": {"type": "config", "message": f"channel.json 缺少 base 配置或表「{a.table}」"}})

    exe = find_cli()
    env = build_env(channel, a.identity)
    # --field-id 支持直接传字段名
    tail = [
        "+record-upload-attachment",
        "--base-token", base_token,
        "--table-id", table_id,
        "--record-id", a.record_id,
        "--field-id", a.field,
    ]
    for p in a.files:
        tail += ["--file", p]
    run_cli(exe, tail, a.identity, env=env)
    print(json.dumps({"ok": True, "record_id": a.record_id, "field": a.field, "files": a.files}, ensure_ascii=False))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("write")
    p1.add_argument("--project-root", required=True)
    p1.add_argument("--table", required=True)
    p1.add_argument("--records-file", required=True)
    # 同步身份统一 bot（铁律 10.1）：不设 argparse choices，改由 check_identity_fence 回 policy 信封
    p1.add_argument("--as", dest="identity", default="bot")

    p2 = sub.add_parser("attach")
    p2.add_argument("--project-root", required=True)
    p2.add_argument("--table", required=True)
    p2.add_argument("--record-id", required=True)
    p2.add_argument("--field", required=True)
    p2.add_argument("--file", dest="files", action="append", required=True)
    p2.add_argument("--as", dest="identity", default="bot")

    a = ap.parse_args()

    # 身份围栏：只走 bot（与 push.py 一致，policy 先于 gate，让调用方先读到形态/身份约束）
    check_identity_fence(a.identity)

    # 出口围栏：状态机未 DONE 拒发（铁律 9.5 指针化后的物理约束）
    check_install_gate(a.project_root)

    if a.cmd == "write":
        cmd_write(a)
    else:
        cmd_attach(a)


if __name__ == "__main__":
    main()
