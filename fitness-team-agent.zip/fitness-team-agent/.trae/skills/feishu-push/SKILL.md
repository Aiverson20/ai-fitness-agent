---
name: feishu-push
description: Pushes team artifacts (text/image/card) to the configured Feishu chat as bot via lark-cli; App Secret read from persistent store. Invoke whenever any deliverable must be pushed to Feishu or a bot-identity send is needed.
---

# feishu-push（飞书推送例程）

团队推送的唯一入口。一切发送到飞书的消息（含 bot 身份发送）必须通过本技能的标准例程执行。本技能同时承担**多维表格数据同步**职责（铁律第十条）。**飞书通道打通职责已移交 `channel-setup` 技能（安装器状态机驱动），本技能不再包含任何打通步骤。**

**出口围栏（三道，代码级物理拒发）**：

1. **通道围栏**：`push.py` / `base_sync.py` 运行前读取 `fitness-team/install-state.json`，通道状态机未 DONE 一律拒发（`error.type="gate"`）。收到 `gate` 错误时：不改数据、不重试、不去手工打通，回到 `channel-setup` 技能把通道打通后重发。
2. **交付形态围栏**：`push.py` 只放行 `text` / `image` / `interactive` 三种消息类型，且正文不得出现本地路径或桌面端链接，违规一律拒发（`error.type="policy"`）。收到 `policy` 错误时：**读 `message` 里的拒发原因与替代形态，改换形态后重发**——不是重试同一条、不是改走手拼 lark-cli 绕过、不是把内容存成文件再发。
3. **交付状态机围栏（铁律 8.6）**：`push.py` 在通道围栏之后串 `installer/delivery.py`，要求每次推送声明 `--product`（铁律 8.1 白名单）并已 `log` 登记落盘，违规一律拒发（`error.type="state"`）。状态流转 `DRAFT → LOGGED → PUSHED → CLOSED`，实例键 `日期|产物|序号`，状态文件 `fitness-team/delivery-state.json` 只由 `delivery.py` / `push.py` 写入，**禁止手工编辑**。各错误码的处理：

| `error.code` | 含义 | 正确动作 |
| --- | --- | --- |
| `missing_product` | 没传 `--product` | 补 `--product`（白名单见 `delivery.py products`），先 log 再推 |
| `product_not_allowed` / `product_unknown` | 产物不在白名单（打卡分数被物理拦在这里） | **即停**，不推送、不换名目绕道；分数只写当日日志 |
| `missing_log` | 产物未登记落盘 | 先确认本地文件已写，再 `delivery.py log`，然后重推 |
| `not_logged` | 实例仍是 DRAFT | 把产物写入本地数据区后 `log` |
| `duplicate` | 当日当产物已 PUSHED | **改用 `--update` 原地改那张卡**，不新发第二条；确属新产物才 `log` 建新序号 |
| `closed` | 实例已归档 | 新产物走 `log` 建新实例 |
| `nothing_to_update` / `update_unavailable` / `update_unsupported` | 无可更新消息 / 无 message_id / 非 interactive | 按 `message` 指引改道（文本、图片消息不能原地更新，只能新建实例重发） |
| `delivery_missing`（`type="environment"`） | 找不到 `installer/delivery.py` | fail-closed 拒发；核对 `--project-root` 指向项目根，分发包缺件重新部署 |

## 标准三步（铁律 8.6，任何产物都一样）

```bash
# ① 产物先写入本地数据区（当日日志 / profile.json / plan.json …），本地文件是唯一事实源
# ② 登记落盘（置 LOGGED；同日同产物未推送的实例会被复用，不撑大序号）
python installer/delivery.py log --project-root <项目根> --date 2026-09-07 --product daily_report --note "daily/2026-09-07.md 晚间汇报章节"
# ③ 推送（成功后例程自动置 PUSHED 并回写 message_id，不依赖调用方自觉）
python .trae/skills/feishu-push/resources/push.py --project-root <项目根> --msg-type interactive --content-file <临时json> --product daily_report --date 2026-09-07
```

**幂等判据（定时任务用这个，不再靠日志文本章节匹配）**：

```bash
python installer/delivery.py query --project-root <项目根> --date 2026-09-07 --product daily_report
# 返回 pushed: true/false —— true 即今天这件产物已推送，静默退出，不再推第二条
# 已归档（CLOSED）也算 true：归档表示这条交付已完成，不是「没交付」；
# 误判成 false 会让定时任务重发第二条，直接违反铁律 8.2 第 4 条。
```

**修正已发出的卡片（铁律 8.6 / M7）**：内容有误或需补充时**原地更新同一条消息**，不新发第二条：

```bash
python .trae/skills/feishu-push/resources/push.py --project-root <项目根> --msg-type interactive --content-file <临时json> --product daily_report --date 2026-09-07 --update
```

例程走飞书官方接口 `PATCH /open-apis/im/v1/messages/:message_id`（lark-cli 无该 typed 命令，走 `api` 逃生舱），并自动为 interactive 卡片注入 `config.update_multi=true`（接口硬要求：更新前后都要带）。接口限制：只能更新**未撤回**的卡片、发送后 **14 天内**、单条消息 **5 QPS**、卡片 ≤30KB，且更新身份须与发送身份一致（团队统一 bot，天然满足）。

## 发送审计与事后对账（铁律 8.6 边界兜底 / M5）

三道围栏只管得住走 `push.py` 的路径，管不住两类：① 直调 lark-cli 绕过例程；② 模型的对话回复被宿主自动卡片化（不经任何例程）。这两类除措辞约束（铁律 9.4.2、8.2 第 4 条）外，由**发送审计 + 事后对账**兜底。

**审计写入（`push.py` 自动完成，调用方无需额外动作）**：每次成功发送/更新追加一行到 `fitness-team/logs/send-audit.jsonl`（时间 / action / 产物 / msg_type / message_id / chat_id / 实例 key）。写盘失败**不阻断已完成的发送**，但信封会标 `audit_written=false` 并另输出一条 `warning="audit_write_failed"`；此时必须人工补记，否则该消息在对账时会被判为「未经例程」。

**对账（排障、验收或怀疑有绕过时跑）**：

```bash
python <项目根>/installer/send_audit.py reconcile --project-root <项目根> --date 2026-09-07
# 脚本路径一律写绝对路径：飞书端（办公助理任务）工作区是 ~\.trae-cn\assistant，不是项目根
# 读会话消息必须用 user 身份（bot 身份没有读权限），例程默认 --as user
# 离线复核已导出的消息：--offline-file <messages.json>；查审计条目：list 子命令
```

分级口径（仅在有 alert 时 `ok=false`）：

| 级别 | 判据 | 含义与动作 |
| --- | --- | --- |
| `alert` | 非白名单形态（file / post / media / audio / sticker）；**或**覆盖期内带 header 的规范卡 / image 不在审计里 | 明确违规。信封里 `form_violation_ids`（形态禁发）与 `bypass_ids`（绕过例程直发）分开列，分别处置 |
| `review` | 无 header 裸卡或文本，且含**产物结构**：markdown 表格 `\|---` / 超长（卡 600、文本 160 字符）/ 特征词 ≥3 个 | 疑似把产物全文塞进对话回复（铁律 8.2 第 4 条），需人工核对 |
| `info` | 短过程确认、无表格短裸卡、用户消息、系统与撤回消息、审计在册、覆盖期前形态合规历史 | 合规或无关，不需动作 |

**三条实测前提，改脚本前必读**：

1. **lark-cli 返回的是渲染视图，不是原始卡片 JSON**：带 header 的规范卡渲染成 `<card title="..." subtitle="...">`，宿主自动卡片化的对话回复渲染成裸 `<card>`，file 渲染成 `<file key="..." name="..."/>`。因此判「有无 header」必须同时认 dict 的 `header` 字段与渲染文本的 `<card title=`（见 `_rendered_card_has_title`），只查 dict 会漏判。
2. **审计有覆盖起点**：`audit_coverage_from` 取最早一条审计的日期，为 `None` 即完全没有审计数据。早于起点的消息属「机制上线前的历史」，**不能拿「不在册」当违规依据**（否则历史合规卡片全被误报），一律降 `info` 并标 `pre_audit=true`；但形态违规与内容级疑点（产物结构）不受覆盖起点影响，照报。
3. **判「产物内嵌」要结构证据，不能只靠特征词**：2026-09-07 实测中，合规的过程性确认（"把加餐补充更新到饮食报告，稍等～"）也顺带提到产物字样，只按特征词判定会把两条合规确认误报成 review，稀释真违规（当日 5 条产物全文裸卡）。加结构判据后 review 桶从 12 条降到 5 条、零误报。

## 核心要点

1. **一律经此技能发送**：所有飞书推送（文本、图片、卡片）都走本技能的标准例程，禁止绕过直接手拼 lark-cli 命令。
2. **复杂 JSON 不内联**：交互卡片、多维表格写入等带复杂 JSON 的调用，JSON 内容先写入临时工作目录下的临时文件，再通过 Python `subprocess.run` 的 argv 数组直调 lark-cli（铁律 9.2）。PowerShell 5.1 会剥离参数中的双引号，已实证两次，不得在命令行参数中内联 JSON。
3. **以 `ok` 判成败**：返回结果的 `ok` 字段为真即成功；失败时把错误信封原样呈现给用户，不盲目重试、不吞错误（铁律 9.3）。
4. **密钥不回显**：App Secret 只注入子进程环境，绝不写入任何项目文件、不回显到输出、不在对话中复述（铁律 9.4）。

## 交付形态（铁律 8.2）

**形态白名单（`push.py` 代码强制，白名单外一律拒发并回传 `policy` 信封）：**

| 形态 | `--msg-type` | 用于 |
| --- | --- | --- |
| Card 2.0 交互卡片 | `interactive` | 档案卡、训练计划卡、晚间汇报卡、周期复盘报告、餐食识别结果等一切结构化产物；表格类内容用卡片内表格呈现 |
| 图片消息 | `image` | 餐食照、训练照、体型照等图片类产物（先上传取 `image_key`） |
| 纯文本 | `text` | 简短通知、定时提醒；卡片生成失败时的降级形态（须在消息中注明降级原因） |

**明令拒发的形态：**

- `file`（任何文件消息）：**html、md、json、xlsx 等本地数据文件原件一律不发**。数据文件是内部实现细节，手机上也打不开项目路径；无论卡片推送成功与否都不补发文件。
- `post` / `media` / `audio` / `sticker` 等其他类型：不在团队交付形态内，围栏直接拒发。

**正文内容禁令（同为代码围栏，命中即拒发）：**

- 不得出现 `computer://`、`file:///` 或任何本地绝对路径（形如 `D:\workProject\...`）。产物路径只在桌面端对话里说，不进飞书消息正文。
- **不生成任何 HTML**：HTML 机制已彻底废除，属**无效产物**（生成了也发不出去）；`fitness-team/plans/`、`fitness-team/reports/` 停用，不得再写入。晚间汇报等产物只有两个落点：本地每日日志（md 存档）＋ 飞书卡片。

**推送范围白名单（铁律 8.1）：** 必推产物为档案卡、训练计划卡、晚间汇报卡、餐食照片识别结果、周期复盘报告，外加早间计划推送与 23:00 补齐/兜底汇报。**训练打卡分数与评语不在必推清单内**：打卡结果只写入当日日志作为晚间汇报素材，不单独推送飞书（详见 `checkin-score`）。白名单外的产物一律不推送；不确定是否该推时按「不推」处理。

## 凭证获取（铁律 9.4）

**主线：办公助理自持凭证。** 用户启用 TraeWork 办公助理并绑定飞书后，桥接凭证文件由宿主管理，`push.py` 自动只读定位（`%APPDATA%\TRAE*\User\globalStorage\cloudide.icube-im-bridge\feishu-bridge\*\channel_config.json` 的 `channels.feishu.workspace` 段），用户零创建应用、零管密钥。

**bot 身份发送时 `push.py` / `base_sync.py` 按主线围栏规则取 App Secret：**

- **主线围栏**：当 `channel.json` 的 `app_id` 即桥接凭证文件的 `appId`（办公助理主线）时，**只读桥接凭证文件**，完全忽略环境变量与注册表残留（已实证：残留旧 Secret 截胡取值链导致 `app secret invalid` code=10014，且注册表删除只对新进程生效，已运行的宿主/终端进程环境块里残留仍在）。
App ID 顺序：`channel.json` 的 `app_id` → 桥接文件 `appId`。自建应用兜底路线已废除：App Secret 环境变量入库通道（含 `save_secret.py`）全部移除，密钥唯一来源是办公助理桥接凭证文件。

## 标准调用

```bash
python resources/push.py --project-root <项目根> --msg-type text --content-file <临时json路径>
```

要点：

- 临时 JSON 文件放临时工作目录（会话级临时目录），不进项目数据区。
- `--chat-id` 省略时读 `fitness-team/channel.json` 的 `target_chat_id`；显式传入优先。
- `--msg-type` 只接受 `text` / `image` / `interactive` 三种；其他类型（含 `file`、`post`、`media`）由交付形态围栏直接拒发并返回 `policy` 信封，读原因改换形态后重发。
- 消息正文（`--content-*`）不得含本地路径或桌面端链接，否则同样返回 `policy` 信封被拒。
- 例程自动完成：lark-cli 定位（PATH 优先，飞书插件目录兜底）、按主线围栏规则取密钥、tenant_access_token 现换（短期有效，不落盘）、argv 直调。

## 首次打通通道（铁律 9.5）→ 指针

通道打通已工程化为安装器状态机，**本技能不再包含任何打通步骤**。需要打通通道时（新项目、`gate` 拒发、用户要求），调用 `channel-setup` 技能运行 `installer/install.py`——六状态硬编码唯一路线，失败即停。禁止在本技能内手工执行任何打通动作（config init、列会话、发测试消息、写 channel.json 全部禁止）。

多维表格权限按需开通：API 报错时把错误信封里的 `console_url` 直链给用户，开通 `base:app:create` / `base:app` / `base:app:readonly` 三档，**开通即时生效，无需发版**。

## 数据同步（铁律第十条）

本地文件写入后，用 `resources/base_sync.py` 同步到多维表格「健身团队 · 数据中心」：

```bash
python resources/base_sync.py write  --project-root <项目根> --table <表名> --records-file <临时json路径>
python resources/base_sync.py attach --project-root <项目根> --table <表名> --record-id recXXX --field <附件字段名> --file <照片路径>
```

- 记录负载格式：`{"create_records": [{"字段名": 值, ...}]}`，`write` 成功后返回 `record_ids`（`attach` 需要）。
- 表位置读 `fitness-team/channel.json` 的 `base` 段（`base_token` + `tables.<表名>` 映射），不硬编码表 ID；缺失即返回 `config` 错误。
- **同步身份统一 `--as bot`**（三档权限足够，已实测）；若报缺权限，把错误信封里的 `console_url` 直链给用户开通，开通即时生效、无需发版。
- 附件先 `write` 再 `attach`；写入前先查同日期同类型记录，避免重复行。
- 同步失败不阻断本地记录，但必须告知用户失败原因与本地文件位置。

## 失败兜底（铁律 8.4）

推送失败必须明确告知用户：失败原因（错误信封原样）＋产物本地文件路径。不谎报成功、不静默丢弃、不自动重试。卡片降级为纯文本时在消息中注明降级原因。

## 常见坑

1. **PowerShell 引号剥离**：带 JSON 的 lark-cli 调用必须 Python argv 直调，绝不在 PowerShell 命令行内联复杂 JSON（已实证两次）。
2. **宿主严格模式**：bot 身份调用须注入 `LARKSUITE_CLI_STRICT_MODE=off`，否则 lark-cli 拒绝执行。
3. **token 时效**：tenant_access_token 约 2 小时过期，每次发送现换，不缓存不落盘。
4. **宿主注入不可靠**：宿主环境变量注入时机不可控（已实证：授权成功后仍可能报 `not configured`），例程自行注入凭证，不依赖宿主。
5. **lark-cli 定位**：PATH 无 lark-cli 时扫描 `~\.trae-cn\plugins\trae-remote-official\lark\*\bin\lark-cli.exe`，多版本取最新。
6. **policy 信封不是重试信号**：`error.type="policy"` 表示形态违规（消息类型不在白名单，或正文含本地路径），本条消息**未发送**。必须改换形态/清掉路径后重发；重试同一条、改用手拼 lark-cli、改用别的通道都属于绕过围栏，禁止。
7. **多维表格附件不受消息白名单约束**：`base_sync.py attach` 是把照片作为附件字段写入多维表格记录，不是发消息，属正常数据同步；只有 `push.py` 的消息类型受白名单限制。
8. **Card 2.0 已移除 `note` 组件**（实证 2026-09-07）：卡片里用 `{"tag":"note"}` 会被飞书 API 拒收，回 `code 230099`、ext `ErrCode: 200861; ErrMsg: cards of schema V2 no longer support this capability; ErrorValue: unsupported tag note`，**整卡发不出去**。脚注、落款一类小字改用 `{"tag":"markdown"}` 配 `<font color='grey'>…</font>`。此类信封 `error.type="api"`（不是 `policy`）：按报错改卡片结构后重发，失败那次不产生消息，不构成重复推送。可复用 `dev-tools/cards/build_cards.py` + `dev-tools/cards/push_cards.py`。
