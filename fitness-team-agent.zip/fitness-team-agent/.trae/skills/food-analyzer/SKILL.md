---
name: food-analyzer
description: "食物图片分析：识别食物种类、估算重量、计算热量与三大营养素（云端 API）。营养师记录三餐照片（meal-photo-check）识别图片时必须调用；用户发送食物照片要求分析时也调用。不得声称无法识别图片。"
version: 1.0.0
---

# Food Analyzer — 食物图片分析 Skill

通过 AI 视觉模型分析食物图片，识别食物种类、估算重量、计算营养信息。

## 团队使用约定（健身团队 · 硬约束）

- 本技能是营养师图片识别的**唯一入口**：`meal-photo-check` 流程的餐食照片必须经本技能识别，禁止回复「无法识别图片」「没有图像识别能力」。
- **用于记录三餐时**：只取 API 返回的 `foods[]`（食物名 + `weight_grams` 大致重量）作为记录素材，按 `meal-photo-check` 流程写入当日日志；**不得**把热量/营养素明细与 `summary` 建议另行发给用户（单餐不点评，全天总账在晚餐后的当日饮食报告中核算）。
- **API 调用失败**：失败即停，如实告知用户失败原因，请用户改用文字补报本餐内容；不得编造记录（铁律 6）。
- **重量估算仅供参考**：API 返回的重量是视觉估算，写入记录时以「大致份量」呈现；用户有异议时以用户更正为准。

## 前置条件

**API 已部署到阿里云函数计算 FC：** https://food-analyzer-ybthpjhnft.cn-hangzhou.fcapp.run

API 地址通过环境变量 `FOOD_ANALYZER_API_URL` 配置，默认使用：
```
https://food-analyzer-ybthpjhnft.cn-hangzhou.fcapp.run
```

## API 调用方式

### 端点

```
POST {FOOD_ANALYZER_API_URL}/api/analyze
Content-Type: application/json
```

### 请求格式

支持两种图片输入方式：

**方式 1 — 图片 URL（推荐，如果图片已有公网链接）：**

```json
{
  "imageUrl": "https://example.com/food-photo.jpg"
}
```

**方式 2 — Base64 编码（适合本地图片）：**

```json
{
  "imageBase64": "/9j/4AAQSk...(完整的base64字符串，不含data:image前缀)",
  "mimeType": "image/jpeg"
}
```

`mimeType` 可选，默认 `image/jpeg`。支持 `image/png`、`image/webp` 等。

### 响应格式

成功响应：

```json
{
  "success": true,
  "analysis": {
    "foods": [
      {
        "name": "食物名称",
        "weight_grams": 250,
        "confidence": "high",
        "calories_kcal": 380,
        "protein_grams": 28.5,
        "carbs_grams": 18.2,
        "fat_grams": 22.0,
        "notes": "补充说明"
      }
    ],
    "total_weight_grams": 450,
    "total_calories_kcal": 612,
    "total_protein_grams": 33.7,
    "total_carbs_grams": 70.0,
    "total_fat_grams": 22.6,
    "summary": "整体评估和饮食建议"
  }
}
```

字段说明：
- `foods[]`: 识别到的每种食物
  - `name`: 食物名称
  - `weight_grams`: 估算重量（克）
  - `confidence`: 置信度（high / medium / low）
  - `calories_kcal`: 估算热量（千卡）
  - `protein_grams` / `carbs_grams` / `fat_grams`: 蛋白质/碳水/脂肪（克）
  - `notes`: 补充说明（可选）
- `total_*`: 所有食物的汇总值
- `summary`: 整体评估文字

错误响应：

```json
{
  "error": "错误描述",
  "detail": "详细信息"
}
```

## 执行流程

当用户提供食物图片并要求分析时：

### Step 1：获取图片

- 如果用户给了 URL → 直接用 `imageUrl`
- 如果是飞书会话发来的图片（办公助理场景）→ 图片已被自动下载到会话工作区的 `.trae\im-files\` 目录（文件名形如 `img_v3_*.jpg`；办公助理会话工作区固定为 `~\.trae-cn\assistant`，故完整落点即 `~\.trae-cn\assistant\.trae\im-files\`），按修改时间取最新一张，直接按本地文件处理
- 如果用户给了本地文件 → 用终端命令将图片转为 base64：

**PowerShell (Windows):**
```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("C:\path\to\image.jpg"))
```

**Bash (Mac/Linux):**
```bash
base64 -i /path/to/image.jpg | tr -d '\n'
```

### Step 2：调用 API

使用终端命令发起 HTTP 请求（本机为 Windows PowerShell 5.1；base64 体积大时，先把请求 JSON 写入临时文件再由脚本读取发送，避免命令行引号解析问题）：

**PowerShell:**
```powershell
$body = @{ imageUrl = "https://example.com/food.jpg" } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri "https://food-analyzer-ybthpjhnft.cn-hangzhou.fcapp.run/api/analyze" -Method POST -ContentType "application/json" -Body $body | ConvertTo-Json -Depth 10
```

**Bash / curl:**
```bash
curl -s -X POST "https://food-analyzer-ybthpjhnft.cn-hangzhou.fcapp.run/api/analyze" \
  -H "Content-Type: application/json" \
  -d '{"imageUrl":"https://example.com/food.jpg"}'
```

### Step 3：呈现结果

将 API 返回的 JSON 数据整理为易读的表格或列表呈现给用户：

1. 列出每种食物的名称、估算重量、热量
2. 展示汇总数据（总重量、总热量、三大营养素）
3. 附上 summary 中的饮食建议
4. 如果 confidence 为 low，提醒用户该估算可能不准确

## 注意事项

- 重量为**视觉估算**，基于食物体积和常见密度推算，存在误差，仅供参考
- 模型对常见食物（米饭、肉类、蔬菜）识别较准，对地方特色菜或加工食品可能不够精确
- 如果图片模糊、食物被遮挡或光线不佳，结果可信度会降低
- 热量和营养素为估算值，不替代专业营养分析

## 部署指南（自建 API 时使用）

API 源码位于本包的 `deploy/` 目录，基于阿里云函数计算 FC 3.0（nodejs18 事件函数 + HTTP 触发器），使用 Serverless Devs（s CLI）部署：

```bash
cd deploy
cp s.yaml.example s.yaml
# 编辑 s.yaml，填入你自己的 QWEN_API_KEY

# 首次使用先配置阿里云凭证
s config add --AccessKeyID xxx --AccessKeySecret xxx -a default -f

# 部署 / 更新
s deploy -y
```

部署完成后，把本文件中所有出现的 API 地址替换为你自己的 `*.fcapp.run` 地址。

配置说明（`s.yaml`）：
- `QWEN_API_KEY`: 阿里云百炼 API Key（环境变量）
- `QWEN_MODEL`: 模型名称（当前 `qwen3.7-plus`）
- `QWEN_BASE_URL`: OpenAI 兼容接口地址（token-plan.cn-beijing.maas.aliyuncs.com）

> 注意：曾尝试部署到 Vercel 和 Cloudflare Workers，均因国内网络访问受限（DNS 污染）放弃，最终落地阿里云 FC（cn-hangzhou），国内直连。
