# Food Analyzer Skill — 分享包

AI 食物图片分析 Skill：识别食物种类、估算重量、计算热量和营养素（蛋白质/碳水/脂肪）。

## 包内容

```
food-analyzer-skill/
├── README.md          # 本说明
├── SKILL.md           # Skill 本体（给 agent 用）
└── deploy/            # API 后端源码（阿里云函数计算 FC）
    ├── index.js       # 函数代码
    ├── package.json
    └── s.yaml.example # 部署配置模板（需填入自己的 API Key）
```

## 使用方式（二选一）

### 方式 A：直接安装 Skill（调用作者已部署的 API）

1. 把 `SKILL.md` 复制到以下目录（没有就创建）：

   - **Windows:** `C:\Users\<你的用户名>\.workbuddy\skills\food-analyzer\SKILL.md`
   - **Mac/Linux:** `~/.workbuddy/skills/food-analyzer/SKILL.md`

2. 重启 WorkBuddy（或重新加载 Skills），即可对 agent 说"分析这张食物图片"来使用。

> ⚠️ 注意：此方式调用的是作者部署的 API，消耗作者账号下的 Qwen 模型额度。适合小范围朋友使用。

### 方式 B：自建部署（用自己的 Key，推荐）

1. **准备账号：**
   - 阿里云账号，开通[函数计算 FC 3.0](https://www.aliyun.com/product/fc)
   - 阿里云百炼（DashScope）API Key（用于调用 qwen3.7-plus 视觉模型）

2. **安装 Serverless Devs CLI：**

   ```bash
   npm install -g @serverless-devs/s
   ```

3. **配置阿里云凭证：**

   ```bash
   s config add --AccessKeyID <你的AccessKeyID> --AccessKeySecret <你的AccessKeySecret> -a default -f
   ```

4. **部署：**

   ```bash
   cd deploy
   cp s.yaml.example s.yaml
   # 编辑 s.yaml，把 QWEN_API_KEY 换成你自己的百炼 API Key
   s deploy -y
   ```

5. 部署完成后会输出一个 `https://xxx.cn-hangzhou.fcapp.run` 地址，把 SKILL.md 中所有出现的旧 API 地址替换成你的新地址即可。

## API 说明

| 端点 | 方法 | 说明 |
|---|---|---|
| `/api/analyze` | POST | 分析食物图片，body 传 `imageUrl` 或 `imageBase64` |
| `/api/health` | GET | 健康检查 |

请求示例：

```bash
curl -s -X POST "https://你的API地址/api/analyze" \
  -H "Content-Type: application/json" \
  -d '{"imageUrl":"https://example.com/food.jpg"}'
```

详细请求/响应格式见 SKILL.md。

## 常见问题

**Q: 为什么部署到阿里云 FC 而不是 Vercel / Cloudflare？**
A: 国内网络访问 vercel.app / workers.dev 存在 DNS 污染，无法直连；阿里云 FC（cn-hangzhou）国内直连无障碍。

**Q: 如何更换模型？**
A: 编辑 `s.yaml` 中的 `QWEN_MODEL` 环境变量，重新 `s deploy -y`。

**Q: 如何更新 API Key？**
A: 编辑 `s.yaml` 中的 `QWEN_API_KEY`，重新 `s deploy -y`，几秒生效。
