// 阿里云函数计算 FC 3.0 — nodejs18 事件函数 + HTTP 触发器
// 食物图片分析 API（Qwen / OpenAI 兼容协议）

const FOOD_ANALYSIS_PROMPT = `你是一个专业的食物识别与营养分析专家。当收到一张包含食物的图片时，你需要：

1. 识别图片中所有可见的食物和饮品（包括配料、酱料等）
2. 根据视觉线索（体积、密度、容器大小、常见份量）估算每种食物的大致重量（克）
3. 估算每种食物的热量（千卡）和主要营养素（蛋白质、碳水化合物、脂肪，单位：克）
4. 给出总体营养评估和简要饮食建议

你必须严格按以下 JSON 格式输出，不要输出 JSON 之外的任何内容：

{
  "foods": [
    {
      "name": "食物名称",
      "weight_grams": 数值（整数，估算重量，单位克）,
      "confidence": "high / medium / low",
      "calories_kcal": 数值（整数，估算热量，单位千卡）,
      "protein_grams": 数值（保留1位小数）,
      "carbs_grams": 数值（保留1位小数）,
      "fat_grams": 数值（保留1位小数）,
      "notes": "补充说明（可选，如烹饪方式、特殊判断依据等）"
    }
  ],
  "total_weight_grams": 所有食物重量之和（整数）,
  "total_calories_kcal": 所有食物热量之和（整数）,
  "total_protein_grams": 蛋白质总和（保留1位小数）,
  "total_carbs_grams": 碳水总和（保留1位小数）,
  "total_fat_grams": 脂肪总和（保留1位小数）,
  "summary": "一段简短的整体评估，2-3句话，包含饮食建议"
}

注意事项：
- 重量估算基于常见食物密度和视觉体积，如果无法精确判断，confidence 标记为 low
- 如果图片中没有食物，返回 {"foods": [], "summary": "图片中未检测到食物"，其余数值字段为 0}
- 如果图片模糊或食物被遮挡，在 notes 中说明`;

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

// ---- 构造 HTTP 响应 ----
function httpResp(statusCode, data, extraHeaders = {}) {
  return {
    isBase64Encoded: false,
    statusCode,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS, ...extraHeaders },
    body: typeof data === "string" ? data : JSON.stringify(data, null, 2),
  };
}

// ---- 解析请求 body ----
function parseBody(event) {
  if (!event.body) return {};
  const raw = event.isBase64Encoded
    ? Buffer.from(event.body, "base64").toString("utf-8")
    : event.body;
  if (!raw) return {};
  return JSON.parse(raw);
}

// ---- 调用 Qwen 分析食物 ----
async function analyzeFood(body, env) {
  const { imageUrl, imageBase64, mimeType = "image/jpeg" } = body;

  if (!imageUrl && !imageBase64) {
    return httpResp(400, {
      error: "请提供 imageUrl 或 imageBase64",
      usage: {
        imageUrl: "图片的公网可访问 URL",
        imageBase64: "图片的 Base64 编码字符串（不含 data:image 前缀）",
        mimeType: "可选，默认 image/jpeg",
      },
    });
  }

  const imageContent = imageUrl
    ? { type: "image_url", image_url: { url: imageUrl } }
    : {
        type: "image_url",
        image_url: { url: `data:${mimeType};base64,${imageBase64}` },
      };

  const apiKey = env.QWEN_API_KEY;
  if (!apiKey) {
    return httpResp(500, { error: "QWEN_API_KEY 未配置，请在函数环境变量中设置" });
  }

  const model = env.QWEN_MODEL || "qwen3.7-plus";
  const baseURL =
    env.QWEN_BASE_URL ||
    "https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1";

  const qwenResponse = await fetch(`${baseURL}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: FOOD_ANALYSIS_PROMPT },
        {
          role: "user",
          content: [
            imageContent,
            {
              type: "text",
              text: "请分析这张图片中的所有食物，识别食物种类、估算重量，并计算营养信息。严格按 JSON 格式输出。",
            },
          ],
        },
      ],
      temperature: 0.3,
      max_tokens: 2000,
    }),
  });

  if (!qwenResponse.ok) {
    const errorText = await qwenResponse.text();
    return httpResp(502, {
      error: "AI 模型调用失败",
      detail: errorText,
      status: qwenResponse.status,
    });
  }

  const data = await qwenResponse.json();
  const content = data.choices?.[0]?.message?.content;

  if (!content) {
    return httpResp(500, { error: "AI 模型未返回有效内容", raw: data });
  }

  // 尝试解析 JSON（模型可能包裹在 ```json ... ``` 中）
  let analysis;
  try {
    const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
    const jsonStr = jsonMatch ? jsonMatch[1].trim() : content.trim();
    analysis = JSON.parse(jsonStr);
  } catch {
    analysis = content;
  }

  return httpResp(200, { success: true, analysis });
}

// ---- Handler 入口（nodejs18 事件函数 + HTTP 触发器格式）----
exports.handler = async (rawEvent, context) => {
  try {
    // event 可能是 Buffer / 字符串（JSON）/ 对象，统一解析
    let event = rawEvent;
    if (Buffer.isBuffer(event)) {
      event = JSON.parse(event.toString("utf-8"));
    } else if (typeof event === "string") {
      event = JSON.parse(event);
    }

    const method = event?.requestContext?.http?.method || "GET";
    const path = event?.rawPath || "/";

    // CORS preflight
    if (method === "OPTIONS") {
      return { isBase64Encoded: false, statusCode: 204, headers: CORS_HEADERS, body: "" };
    }

    // GET / — API 说明
    if (path === "/" && method === "GET") {
      return httpResp(200, {
        name: "Food Analyzer API",
        version: "1.0.0",
        platform: "Alibaba Cloud Function Compute",
        endpoints: {
          "POST /api/analyze": "分析图片中的食物",
          "GET /api/health": "健康检查",
        },
        usage: {
          description: "POST 请求，body 支持 imageUrl 或 imageBase64",
          example_url: { imageUrl: "https://example.com/food.jpg" },
          example_base64: {
            imageBase64: "/9j/4AAQ...(base64字符串)",
            mimeType: "image/jpeg",
          },
        },
      });
    }

    // GET /api/health — 健康检查
    if (path === "/api/health" && method === "GET") {
      return httpResp(200, {
        status: "ok",
        timestamp: new Date().toISOString(),
        model: process.env.QWEN_MODEL || "qwen3.7-plus",
        apiKeyConfigured: !!process.env.QWEN_API_KEY,
      });
    }

    // POST /api/analyze — 食物分析
    if (path === "/api/analyze" && method === "POST") {
      let body;
      try {
        body = parseBody(event);
      } catch {
        return httpResp(400, { error: "请求体不是有效的 JSON" });
      }
      return await analyzeFood(body, process.env);
    }

    // 404
    return httpResp(404, { error: "Not Found" });
  } catch (error) {
    return httpResp(500, { error: "分析失败", detail: error.message });
  }
};
