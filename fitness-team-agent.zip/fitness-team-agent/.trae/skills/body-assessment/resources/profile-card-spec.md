# 人物卡片规格 · profile-card（飞书 Card 2.0 交互卡片）

归属角色：大总管（由处理建档、重测、体重记录的角色在写入数据后执行）。

## 形态与铁律

- 人物卡片**只以飞书 Card 2.0 交互卡片形态交付**，经 `feishu-push` 技能推送。
- **HTML 属无效产物**：不生成任何本地 HTML 卡片（`profile-card.html` 已废除）；**不得把 `profile.json` 等数据文件发给用户**（铁律 8.2）。交付形态已代码围栏——`push.py` 只放行 `text` / `image` / `interactive`，文件消息物理拒发并回传 `error.type="policy"` 信封；卡片正文也不得出现 `computer://`、`file:///` 或盘符绝对路径。收到 `policy` 信封读原因改换形态重发，不补发文件、不绕过。
- 档案数据写入与卡片推送均属安全操作，直接执行、不逐条征求用户确认（见铁律「安全操作免确认」）。

## 触发

- 档案数据写入后（建档、周期重测、记录体重时）同步推送最新卡片；同一事件的卡片只推一次。

## 数据来源

- 只读取 `fitness-team/profile.json` 与 `fitness-team/plan.json`；不编造任何数字；未测量、未建档的字段显示「—」。

## 卡片内容

1. **标题区**：卡片标题「我的档案卡」+ 称呼（取 `profile.json` 的 `basic.nickname`，缺失时显示「—」）；副标题一句话目标（取 `profile.json` 的 `goal`）。
2. **核心指标区**（用卡片分栏/字段组件整齐排布，突出关键数字）：
   - 最新体重（公斤）与体脂率（取 `body_log` 最后一条），附采集日期；
   - 建档天数：`registration_date` 到今日的天数。
3. **身体数据表**：身高、体重、腰围、臀围、胸围、体脂率及其采集日期，用卡片表格或多列字段呈现（飞书原生表格能力），缺项显示「—」。
4. **当前周期**：读 `plan.json` 的 `current_cycle`（周期名与起止日期）；无计划显示「待生成」。
5. **底部备注**：生成时间与「档案每次更新后本卡自动同步」。

## 形象图片（可选）

- 默认不带形象图片。用户提供自己的形象图片时，先经 `feishu-push` 上传图片取得 `image_key`，再在卡片顶部插入图片组件；不内嵌任何 SVG。

## 推送方式

- 卡片 JSON 按铁律 9 处理：先写入临时工作目录的临时文件，经 Python `subprocess.run` argv 数组调用 lark-cli，以返回 `ok` 字段判定成败；失败按铁律 8.4 兜底（告知失败原因与本地档案位置，不谎报、不静默、不自动重试）。
- 推送内容必须与 `profile.json` 一致（铁律 8.5）；数据更新后重新推送覆盖最新状态。

## 其他约定

- **禁用 `note` 组件**（实测 2026-09-07：Card 2.0 已移除该能力，飞书 API 拒收 `code 230099` / ext `ErrCode 200861 unsupported tag note`，整卡发不出去）；底部备注一类小字用 `markdown` 元素配 `<font color='grey'>…</font>` 呈现。此类 `error.type="api"` 信封与 `policy` 信封不同：按报错改卡片结构后重发即可，失败的那次不产生消息、不会重复推送。
- 卡片 JSON 可直接用归档构造器生成：`dev-tools/cards/build_cards.py`（`--only profile`），推送用 `dev-tools/cards/push_cards.py`。
- 全文中文，日期 `YYYY-MM-DD`。
