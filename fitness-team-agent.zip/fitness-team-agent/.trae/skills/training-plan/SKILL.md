---
name: training-plan
description: 基于档案与动作库生成三周期训练计划，以双周块（2 周）为单位滚动。节点日（每两周的周一）训练师在 09:00 定时任务中主动排好未来两周计划、入档并推送两周计划卡请用户确认或修改，节点日不得静默。体测完成后、用户说「今天」「计划」或到达节点日时调用。
---

# 双周训练计划生成与节点日滚动

训练计划以**双周块**为单位：一次排 2 周（14 天），块与块首尾相接；每个块的首周周一定为**节点日**。用户随时可以要求修改（走 `plan-adjust`），改完仍属当前块，不打乱节奏。

## 节奏约定（plan_cadence）

- `plan.json` 的 `plan_cadence` 是节奏的唯一依据：`block_weeks: 2`、`node_weekday: 周一`、`anchor_date`、`current_block`、`next_node_date`、`node_dates`。
- **是否节点日只看 `next_node_date` 是否等于今天**，不要靠「今天是周一」推断（用户可能手动改过节奏或跳过节点日）。
- 排完一个块并写入 `plan.json` 后，**必须把 `next_node_date` 推进 14 天**、`current_block` 加 1。
- 三大周期由双周块拼成：周期 2、周期 3 各 4 周（2 个块）；周期 1 适应期因首周已在旧节奏下执行完为 3 周。**周期边界与块边界对齐**，块不跨周期。

## 节点日纪律（硬约束）

- 节点日的 09:00 定时任务**不得静默退出**：训练师直接排好未来两周计划 → 写入 `plan.json` → 状态机登记 → 推送**两周计划卡**（Card 2.0）→ 卡内与回复中请用户**确认或提出修改**。用户不回视为默认接受，当日安排照常执行。
- 用户提出修改：走 `plan-adjust`，只改用户指出的部分，写回当前块；已发出的计划卡**用 `push.py --update` 原地更新同一张卡**，不新发第二条（铁律 8.2 第 4 条）。
- 只有三种情况可以不推送：① `install-state.json` 的 `feishu_channel` 非 `DONE`（通道未打通，静默退出）；② **幂等判据（机器判据，唯一依据）**——交付状态机查得今日早间推送已发出，静默退出：

  ```
  python installer/delivery.py query --project-root <项目根> --date <今天 YYYY-MM-DD> --product morning_plan
  ```

  读信封的 `pushed` 布尔：`true` → 今日已推送，**不重复推送**；`false` → 正常推送。当日日志的「早间计划推送」标记仍是本地事实源，但**只作人读视图，不作幂等判据**（文本匹配不可靠）。
  ③ 档案或动作库为空导致无法排计划（此时如实告知缺什么，不编造计划）。
- **产物标识分工**（状态机按 `日期|产物|序号` 记实例，标错会互相误判幂等）：09:00 定时任务无论节点日还是非节点日一律用 `--product morning_plan`；用户在对话中主动索取计划或计划变更用 `--product training_plan`；`plan-adjust` 的调整确认卡用 `--product plan_adjust`。

## 工作流程

1. 读取 `fitness-team/profile.json`（目标、体测数据）、`fitness-team/moves.json`（会做的动作）、`fitness-team/plan.json`（节奏、当前块、上一块安排）、`fitness-team/daily/` 最近两周日志（完成度与分数）。
2. 读取知识库 `references/training-plans.md`，按 `references/principles.md` 定三大周期主题与双周块边界；周期长度、块数与起止日期写入 `plan.json` 的 `cycles` 与 `biweek_blocks`。
3. **生成当前双周块计划**：在 `week_plan` 中追加两条周条目（每周一条，各带 `block` 序号与 `start`/`end`），14 天逐日给出安排——训练日列动作清单（组数 × 次数 × 负荷，每个动作附一句关键提醒，提醒取自动作库该动作的 `cue`），休息日只写「计划休息」。块级信息（主题、上一块回顾、渐进决策）写入 `biweek_blocks` 对应块。
4. **渐进决策**：以上一块（首个块以最近一周）的实际完成度与分数为依据，遵循 `principles.md` 的渐进原则——**一次只动一个变量**（次数、组数、负荷、时长择一）；未完成的日子按原参数重排，不加码惩罚。决策写入块的 `progression_decision`。
5. 检查体测数据 `collected_at` 距今是否满 14 天：满 14 天则在块内相应日期挂复测提醒（写入该日 `note`，早间推送时一并带出），并建议块结束后走 `body-assessment` 重测。
6. **沿用机制**：上一块执行得好（分数稳定、无未完成日）可整块沿用参数，只更新块的 `planned_at` 与日期；同一周期内不必每块都变。
7. 写回 `plan.json`：更新 `week_plan`、`biweek_blocks`、`plan_cadence`（`current_block`、`next_node_date`）、`last_updated`；同步校准 `meal_plan` 的 `aligned_block`、`calibrated_at`、`calibration_note`——配餐仍按星期几的一周模板，只随块校准训练日与休息日分布，模板本身不必每块改。
8. 输出**两周计划卡**：按 `resources/plan-card-spec.md` 组装 Card 2.0 交互卡片，**卡内高亮今日安排**，经 `feishu-push` 技能推送到目标会话，并请用户确认或修改。推送走**标准三步**（状态机是推送的前置条件，未登记会被 `push.py` 以 `missing_log` 拒发）：

   ```
   :: ① 计划写入 plan.json（本地事实源）
   :: ② 状态机登记实例
   python installer/delivery.py log --project-root <项目根> --date <今天 YYYY-MM-DD> --product morning_plan --note "早间计划推送"
   :: ③ 推送（成功后例程自动回写 PUSHED 与 message_id）
   python .trae/skills/feishu-push/resources/push.py --project-root <项目根> ^
     --msg-type interactive --content-file <卡片 JSON 临时文件> ^
     --product morning_plan --date <今天 YYYY-MM-DD>
   ```

   推送成功后在 `fitness-team/daily/YYYY-MM-DD.md` 写「早间计划推送」标记作为**人读视图**（本地日志是唯一事实源，飞书仅为展示层），但幂等判据只认状态机（见「节点日纪律」）。卡片内容有变时用同一条 `push.py` 命令加 `--update` 原地改卡，不新发消息。
9. 用户说「今天」时，从当前块读取当天安排，直接给出动作清单与关键提醒，不重新排计划。

## 铁律边界

- 排计划时**不设计任何需要照片判定姿势的环节**，不提供姿势纠正建议（铁律 2）。
- 用户提到受伤或身体不适，立即建议停止训练并就医，本技能不给医疗或康复方案（铁律 5）。
- 计划中的动作只从动作库已掌握动作中选取；需要新动作时先走 `move-library` 登记。不编造用户未汇报的完成情况（铁律 6）。
- 计划卡**只以飞书 Card 2.0 交互卡片交付**，**禁止**生成任何 HTML 计划卡或存档，`fitness-team/plans/` 已停用（铁律 8.2）。飞书消息正文与卡片字段不得出现 `computer://`、`file:///` 或任何本地绝对路径，`push.py` 会物理拒发并回传 `error.type="policy"` 信封；收到 `policy` 信封按原因改换合规形态重发（卡片→纯文本），不绕过出口围栏。
- 计划卡属铁律 8.1 推送白名单，生成后必须推送，不得只落本地不通知。
